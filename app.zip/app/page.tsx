import Image from "next/image"
import { redirect } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function LoginPage() {
  async function handleLogin(formData: FormData) {
    "use server"
    // Aquí iría la lógica de autenticación real
    // Por ahora, simplemente redirigimos al dashboard
    redirect("/dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col bg-slate-50">
      <div className="flex flex-1 flex-col items-center justify-center p-4">
        <div className="w-full max-w-md space-y-8 rounded-xl bg-white p-8 shadow-lg">
          <div className="flex flex-col items-center space-y-2 text-center">
            <div className="relative h-32 w-64">
              <Image
                src="/images/logo-el-filo.png"
                alt="Logo de El Filo Barbería"
                fill
                className="object-contain"
                priority
              />
            </div>
            <p className="text-sm text-gray-500">Sistema de Gestión</p>
          </div>

          <form action={handleLogin} className="space-y-6">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Usuario</Label>
                <Input
                  id="username"
                  name="username"
                  placeholder="Ingrese su nombre de usuario"
                  required
                  className="w-full"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">Contraseña</Label>
                <Input
                  id="password"
                  name="password"
                  type="password"
                  placeholder="Ingrese su contraseña"
                  required
                  className="w-full"
                />
              </div>
            </div>

            <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600">
              Iniciar Sesión
            </Button>
          </form>

          <div className="mt-4 text-center text-sm text-gray-500">
            <p>© 2025 Barbería "El Filo" - Todos los derechos reservados</p>
          </div>
        </div>
      </div>
    </div>
  )
}
