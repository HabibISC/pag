"use client"

import { useState } from "react"
import { format, addDays, startOfWeek, addWeeks, subWeeks, isSameDay, parseISO } from "date-fns"
import { es } from "date-fns/locale"
import { Calendar, ChevronLeft, ChevronRight, Clock, Filter, MoreVertical, Plus } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"

// Tipos
export interface Barbero {
  id: number
  nombre: string
  color: string
}

export interface Cliente {
  id: number
  nombre: string
  telefono: string
  email: string
}

export interface Servicio {
  id: number
  nombre: string
  duracion: number
  costo: number
}

export interface Cita {
  id: number
  clienteId: number
  servicioId: number
  barberoId: number
  fecha: string
  hora: string
  estado: "confirmada" | "pendiente" | "cancelada" | "completada"
  notas?: string
}

// Datos de ejemplo
const barberos: Barbero[] = [
  { id: 1, nombre: "Juan Pérez", color: "#f59e0b" },
  { id: 2, nombre: "Miguel Rodríguez", color: "#3b82f6" },
  { id: 3, nombre: "Carlos Sánchez", color: "#10b981" },
]

const clientes: Cliente[] = [
  { id: 1, nombre: "Roberto Gómez", telefono: "555-1234", email: "roberto@ejemplo.com" },
  { id: 2, nombre: "Luis Hernández", telefono: "555-5678", email: "luis@ejemplo.com" },
  { id: 3, nombre: "Fernando Torres", telefono: "555-9012", email: "fernando@ejemplo.com" },
  { id: 4, nombre: "Alejandro Martínez", telefono: "555-3456", email: "alejandro@ejemplo.com" },
  { id: 5, nombre: "Diego Ramírez", telefono: "555-7890", email: "diego@ejemplo.com" },
]

const servicios: Servicio[] = [
  { id: 1, nombre: "Corte de cabello", duracion: 30, costo: 150 },
  { id: 2, nombre: "Afeitado tradicional", duracion: 25, costo: 120 },
  { id: 3, nombre: "Corte y barba", duracion: 45, costo: 250 },
  { id: 4, nombre: "Fade", duracion: 35, costo: 180 },
  { id: 5, nombre: "Lavado y peinado", duracion: 20, costo: 100 },
]

const citasIniciales: Cita[] = [
  {
    id: 1,
    clienteId: 1,
    servicioId: 1,
    barberoId: 1,
    fecha: "2025-04-23",
    hora: "10:00",
    estado: "confirmada",
  },
  {
    id: 2,
    clienteId: 2,
    servicioId: 3,
    barberoId: 2,
    fecha: "2025-04-23",
    hora: "11:30",
    estado: "pendiente",
  },
  {
    id: 3,
    clienteId: 3,
    servicioId: 2,
    barberoId: 3,
    fecha: "2025-04-23",
    hora: "14:00",
    estado: "confirmada",
  },
  {
    id: 4,
    clienteId: 4,
    servicioId: 4,
    barberoId: 1,
    fecha: "2025-04-24",
    hora: "09:30",
    estado: "confirmada",
  },
  {
    id: 5,
    clienteId: 5,
    servicioId: 5,
    barberoId: 2,
    fecha: "2025-04-24",
    hora: "16:00",
    estado: "cancelada",
  },
]

export default function CitasPage() {
  // Estados
  const [citas, setCitas] = useState<Cita[]>(citasIniciales)
  const [citaActual, setCitaActual] = useState<Cita | null>(null)
  const [modalCita, setModalCita] = useState(false)
  const [modalTransferir, setModalTransferir] = useState(false)
  const [modalCancelar, setModalCancelar] = useState(false)
  const [fechaSeleccionada, setFechaSeleccionada] = useState(new Date())
  const [vistaActual, setVistaActual] = useState<"dia" | "semana">("semana")
  const [semanaActual, setSemanaActual] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }))
  const [nuevoBarberoId, setNuevoBarberoId] = useState<string>("")

  // Filtros
  const [filtroCliente, setFiltroCliente] = useState<string>("")
  const [filtroBarbero, setFiltroBarbero] = useState<string>("todos")
  const [filtroFecha, setFiltroFecha] = useState<string>("")
  const [modalFiltros, setModalFiltros] = useState(false)

  // Toast para notificaciones
  const { toast } = useToast()

  // Obtener citas filtradas
  const citasFiltradas = citas.filter((cita) => {
    const pasaFiltroCliente = filtroCliente
      ? clientes
          .find((c) => c.id === cita.clienteId)
          ?.nombre.toLowerCase()
          .includes(filtroCliente.toLowerCase())
      : true

    const pasaFiltroBarbero =
      filtroBarbero && filtroBarbero !== "todos" ? cita.barberoId === Number(filtroBarbero) : true

    const pasaFiltroFecha = filtroFecha ? cita.fecha === filtroFecha : true

    return pasaFiltroCliente && pasaFiltroBarbero && pasaFiltroFecha
  })

  // Obtener citas del día seleccionado
  const citasDelDia = citas.filter((cita) => cita.fecha === format(fechaSeleccionada, "yyyy-MM-dd"))

  // Generar días de la semana actual
  const diasSemana = Array.from({ length: 7 }, (_, i) => addDays(semanaActual, i))

  // Función para crear una nueva cita
  const crearCita = (nuevaCita: Omit<Cita, "id">) => {
    const id = Math.max(...citas.map((c) => c.id), 0) + 1
    const citaCompleta = { ...nuevaCita, id }
    setCitas([...citas, citaCompleta])
    setModalCita(false)

    toast({
      title: "Cita agendada",
      description: `Se ha agendado correctamente la cita para ${format(parseISO(nuevaCita.fecha), "PPP", { locale: es })} a las ${nuevaCita.hora}`,
    })
  }

  // Función para modificar una cita existente
  const modificarCita = (citaModificada: Cita) => {
    setCitas(citas.map((c) => (c.id === citaModificada.id ? citaModificada : c)))
    setModalCita(false)

    toast({
      title: "Cita modificada",
      description: "Se han guardado los cambios en la cita correctamente",
    })
  }

  // Función para transferir una cita a otro barbero
  const transferirCita = (citaId: number, nuevoBarberoId: number) => {
    setCitas(
      citas.map((c) =>
        c.id === citaId
          ? {
              ...c,
              barberoId: nuevoBarberoId,
            }
          : c,
      ),
    )
    setModalTransferir(false)

    toast({
      title: "Cita transferida",
      description: `La cita ha sido transferida a ${barberos.find((b) => b.id === nuevoBarberoId)?.nombre}`,
    })
  }

  // Función para cancelar una cita
  const cancelarCita = (citaId: number) => {
    setCitas(
      citas.map((c) =>
        c.id === citaId
          ? {
              ...c,
              estado: "cancelada",
            }
          : c,
      ),
    )
    setModalCancelar(false)

    toast({
      title: "Cita cancelada",
      description: "La cita ha sido cancelada correctamente",
      variant: "destructive",
    })
  }

  // Función para abrir el formulario de nueva cita
  const abrirNuevaCita = () => {
    setCitaActual(null)
    setModalCita(true)
  }

  // Función para abrir el formulario de edición de cita
  const abrirEditarCita = (cita: Cita) => {
    setCitaActual(cita)
    setModalCita(true)
  }

  // Función para abrir el modal de transferencia
  const abrirTransferirCita = (cita: Cita) => {
    setCitaActual(cita)
    setNuevoBarberoId("")
    setModalTransferir(true)
  }

  // Función para abrir el modal de cancelación
  const abrirCancelarCita = (cita: Cita) => {
    setCitaActual(cita)
    setModalCancelar(true)
  }

  // Cambiar a la semana anterior
  const semanaAnterior = () => {
    setSemanaActual(subWeeks(semanaActual, 1))
  }

  // Cambiar a la semana siguiente
  const semanaSiguiente = () => {
    setSemanaActual(addWeeks(semanaActual, 1))
  }

  // Cambiar a la semana actual
  const semanaHoy = () => {
    setSemanaActual(startOfWeek(new Date(), { weekStartsOn: 1 }))
    setFechaSeleccionada(new Date())
  }

  // Limpiar filtros
  const limpiarFiltros = () => {
    setFiltroCliente("")
    setFiltroBarbero("todos")
    setFiltroFecha("")
    setModalFiltros(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Gestión de Citas</h1>
          <p className="text-muted-foreground">Agenda y administra las citas de la barbería</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={abrirNuevaCita} className="bg-amber-500 hover:bg-amber-600">
            <Plus className="mr-2 h-4 w-4" />
            Nueva Cita
          </Button>
          <Popover open={modalFiltros} onOpenChange={setModalFiltros}>
            <PopoverTrigger asChild>
              <Button variant="outline">
                <Filter className="mr-2 h-4 w-4" />
                Filtros
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80">
              <div className="grid gap-4">
                <div className="space-y-2">
                  <h4 className="font-medium leading-none">Filtrar Citas</h4>
                  <p className="text-sm text-muted-foreground">Aplica filtros para encontrar citas específicas</p>
                </div>
                <div className="grid gap-2">
                  <div className="grid gap-1">
                    <Label htmlFor="filtroCliente">Cliente</Label>
                    <Input
                      id="filtroCliente"
                      placeholder="Buscar por nombre..."
                      value={filtroCliente}
                      onChange={(e) => setFiltroCliente(e.target.value)}
                    />
                  </div>
                  <div className="grid gap-1">
                    <Label htmlFor="filtroBarbero">Barbero</Label>
                    <Select value={filtroBarbero} onValueChange={setFiltroBarbero}>
                      <SelectTrigger id="filtroBarbero">
                        <SelectValue placeholder="Seleccionar barbero" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="todos">Todos los barberos</SelectItem>
                        {barberos.map((barbero) => (
                          <SelectItem key={barbero.id} value={barbero.id.toString()}>
                            {barbero.nombre}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid gap-1">
                    <Label htmlFor="filtroFecha">Fecha</Label>
                    <Input
                      id="filtroFecha"
                      type="date"
                      value={filtroFecha}
                      onChange={(e) => setFiltroFecha(e.target.value)}
                    />
                  </div>
                  <div className="flex justify-between pt-2">
                    <Button variant="outline" size="sm" onClick={limpiarFiltros}>
                      Limpiar filtros
                    </Button>
                    <Button size="sm" onClick={() => setModalFiltros(false)}>
                      Aplicar
                    </Button>
                  </div>
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </div>

      <Tabs defaultValue="calendario" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="calendario">
            <Calendar className="mr-2 h-4 w-4" />
            Calendario
          </TabsTrigger>
          <TabsTrigger value="listado">
            <Clock className="mr-2 h-4 w-4" />
            Listado de Citas
          </TabsTrigger>
        </TabsList>
        <TabsContent value="calendario" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="icon" onClick={semanaAnterior}>
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" onClick={semanaHoy}>
                    Hoy
                  </Button>
                  <Button variant="outline" size="icon" onClick={semanaSiguiente}>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
                <div className="text-lg font-semibold">{format(semanaActual, "MMMM yyyy", { locale: es })}</div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant={vistaActual === "dia" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setVistaActual("dia")}
                  >
                    Día
                  </Button>
                  <Button
                    variant={vistaActual === "semana" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setVistaActual("semana")}
                  >
                    Semana
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {vistaActual === "semana" ? (
                <div className="grid grid-cols-7 gap-2">
                  {diasSemana.map((dia) => (
                    <div
                      key={format(dia, "yyyy-MM-dd")}
                      className={`rounded-lg border p-2 ${
                        isSameDay(dia, new Date()) ? "bg-amber-50 border-amber-200" : ""
                      } ${isSameDay(dia, fechaSeleccionada) ? "ring-2 ring-amber-500" : ""} cursor-pointer`}
                      onClick={() => setFechaSeleccionada(dia)}
                    >
                      <div className="text-center">
                        <div className="text-xs text-gray-500">{format(dia, "EEEE", { locale: es })}</div>
                        <div className="text-lg font-semibold">{format(dia, "d")}</div>
                      </div>
                      <div className="mt-2 space-y-1">
                        {citas
                          .filter((cita) => cita.fecha === format(dia, "yyyy-MM-dd"))
                          .slice(0, 3)
                          .map((cita) => {
                            const cliente = clientes.find((c) => c.id === cita.clienteId)
                            const barbero = barberos.find((b) => b.id === cita.barberoId)
                            return (
                              <div
                                key={cita.id}
                                className={`rounded-md p-1 text-xs ${
                                  cita.estado === "confirmada"
                                    ? "bg-green-100 text-green-800"
                                    : cita.estado === "pendiente"
                                      ? "bg-amber-100 text-amber-800"
                                      : "bg-red-100 text-red-800"
                                }`}
                                style={{ borderLeft: `3px solid ${barbero?.color || "#000"}` }}
                                onClick={(e) => {
                                  e.stopPropagation()
                                  abrirEditarCita(cita)
                                }}
                              >
                                <div className="font-medium">{cita.hora}</div>
                                <div className="truncate">{cliente?.nombre}</div>
                              </div>
                            )
                          })}
                        {citas.filter((cita) => cita.fecha === format(dia, "yyyy-MM-dd")).length > 3 && (
                          <div className="text-center text-xs text-gray-500">
                            +{citas.filter((cita) => cita.fecha === format(dia, "yyyy-MM-dd")).length - 3} más
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="text-center text-lg font-semibold">
                    {format(fechaSeleccionada, "EEEE, d 'de' MMMM", { locale: es })}
                  </div>
                  <div className="space-y-2">
                    {citasDelDia.length > 0 ? (
                      citasDelDia.map((cita) => {
                        const cliente = clientes.find((c) => c.id === cita.clienteId)
                        const servicio = servicios.find((s) => s.id === cita.servicioId)
                        const barbero = barberos.find((b) => b.id === cita.barberoId)
                        return (
                          <div
                            key={cita.id}
                            className="flex items-center justify-between rounded-lg border p-3"
                            style={{ borderLeft: `4px solid ${barbero?.color || "#000"}` }}
                          >
                            <div className="flex items-center gap-3">
                              <div className="text-lg font-semibold">{cita.hora}</div>
                              <div>
                                <div className="font-medium">{cliente?.nombre}</div>
                                <div className="text-sm text-gray-500">{servicio?.nombre}</div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge
                                variant="outline"
                                className={
                                  cita.estado === "confirmada"
                                    ? "bg-green-50 text-green-700"
                                    : cita.estado === "pendiente"
                                      ? "bg-amber-50 text-amber-700"
                                      : "bg-red-50 text-red-700"
                                }
                              >
                                {cita.estado === "confirmada"
                                  ? "Confirmada"
                                  : cita.estado === "pendiente"
                                    ? "Pendiente"
                                    : "Cancelada"}
                              </Badge>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreVertical className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => abrirEditarCita(cita)}>Editar</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => abrirTransferirCita(cita)}>
                                    Transferir
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem className="text-red-600" onClick={() => abrirCancelarCita(cita)}>
                                    Cancelar
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </div>
                        )
                      })
                    ) : (
                      <div className="rounded-lg border border-dashed p-8 text-center">
                        <h3 className="text-lg font-medium">No hay citas para este día</h3>
                        <p className="mt-1 text-sm text-gray-500">
                          Haz clic en "Nueva Cita" para agendar una cita en esta fecha
                        </p>
                        <Button onClick={abrirNuevaCita} className="mt-4 bg-amber-500 hover:bg-amber-600">
                          <Plus className="mr-2 h-4 w-4" />
                          Nueva Cita
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="listado" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Listado de Citas</CardTitle>
              <CardDescription>Visualiza todas las citas programadas y su información detallada</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b bg-muted/50 text-left">
                      <th className="p-2 pl-4">Cliente</th>
                      <th className="p-2">Servicio</th>
                      <th className="p-2">Barbero</th>
                      <th className="p-2">Fecha</th>
                      <th className="p-2">Hora</th>
                      <th className="p-2">Estado</th>
                      <th className="p-2 text-right">Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {citasFiltradas.length > 0 ? (
                      citasFiltradas.map((cita) => {
                        const cliente = clientes.find((c) => c.id === cita.clienteId)
                        const servicio = servicios.find((s) => s.id === cita.servicioId)
                        const barbero = barberos.find((b) => b.id === cita.barberoId)
                        return (
                          <tr key={cita.id} className="border-b">
                            <td className="p-2 pl-4 font-medium">{cliente?.nombre}</td>
                            <td className="p-2">{servicio?.nombre}</td>
                            <td className="p-2">
                              <div className="flex items-center gap-2">
                                <div className="h-3 w-3 rounded-full" style={{ backgroundColor: barbero?.color }}></div>
                                {barbero?.nombre}
                              </div>
                            </td>
                            <td className="p-2">{format(parseISO(cita.fecha), "dd/MM/yyyy")}</td>
                            <td className="p-2">{cita.hora}</td>
                            <td className="p-2">
                              <Badge
                                variant="outline"
                                className={
                                  cita.estado === "confirmada"
                                    ? "bg-green-50 text-green-700"
                                    : cita.estado === "pendiente"
                                      ? "bg-amber-50 text-amber-700"
                                      : "bg-red-50 text-red-700"
                                }
                              >
                                {cita.estado === "confirmada"
                                  ? "Confirmada"
                                  : cita.estado === "pendiente"
                                    ? "Pendiente"
                                    : "Cancelada"}
                              </Badge>
                            </td>
                            <td className="p-2 text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreVertical className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => abrirEditarCita(cita)}>Editar</DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => abrirTransferirCita(cita)}>
                                    Transferir
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem className="text-red-600" onClick={() => abrirCancelarCita(cita)}>
                                    Cancelar
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </td>
                          </tr>
                        )
                      })
                    ) : (
                      <tr>
                        <td colSpan={7} className="p-4 text-center">
                          No se encontraron citas con los filtros aplicados
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Modal para crear/editar cita */}
      <Dialog open={modalCita} onOpenChange={setModalCita}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{citaActual ? "Modificar Cita" : "Nueva Cita"}</DialogTitle>
            <DialogDescription>
              {citaActual
                ? "Modifica los detalles de la cita seleccionada"
                : "Completa los campos para agendar una nueva cita"}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="cliente">Cliente</Label>
              <Select
                value={citaActual?.clienteId.toString() || ""}
                onValueChange={(value) => {
                  if (citaActual) {
                    setCitaActual({ ...citaActual, clienteId: Number(value) })
                  }
                }}
              >
                <SelectTrigger id="cliente">
                  <SelectValue placeholder="Seleccionar cliente" />
                </SelectTrigger>
                <SelectContent>
                  {clientes.map((cliente) => (
                    <SelectItem key={cliente.id} value={cliente.id.toString() || "default"}>
                      {cliente.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="servicio">Servicio</Label>
              <Select
                value={citaActual?.servicioId.toString() || ""}
                onValueChange={(value) => {
                  if (citaActual) {
                    setCitaActual({ ...citaActual, servicioId: Number(value) })
                  }
                }}
              >
                <SelectTrigger id="servicio">
                  <SelectValue placeholder="Seleccionar servicio" />
                </SelectTrigger>
                <SelectContent>
                  {servicios.map((servicio) => (
                    <SelectItem key={servicio.id} value={servicio.id.toString() || "default"}>
                      {servicio.nombre} ({servicio.duracion} min - ${servicio.costo})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="barbero">Barbero</Label>
              <Select
                value={citaActual?.barberoId.toString() || ""}
                onValueChange={(value) => {
                  if (citaActual) {
                    setCitaActual({ ...citaActual, barberoId: Number(value) })
                  }
                }}
              >
                <SelectTrigger id="barbero">
                  <SelectValue placeholder="Seleccionar barbero" />
                </SelectTrigger>
                <SelectContent>
                  {barberos.map((barbero) => (
                    <SelectItem key={barbero.id} value={barbero.id.toString() || "default"}>
                      {barbero.nombre}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="fecha">Fecha</Label>
                <Input
                  id="fecha"
                  type="date"
                  value={citaActual?.fecha || format(fechaSeleccionada, "yyyy-MM-dd")}
                  onChange={(e) => {
                    if (citaActual) {
                      setCitaActual({ ...citaActual, fecha: e.target.value })
                    }
                  }}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="hora">Hora</Label>
                <Input
                  id="hora"
                  type="time"
                  value={citaActual?.hora || ""}
                  onChange={(e) => {
                    if (citaActual) {
                      setCitaActual({ ...citaActual, hora: e.target.value })
                    }
                  }}
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="estado">Estado</Label>
              <Select
                value={citaActual?.estado || "pendiente"}
                onValueChange={(value) => {
                  if (citaActual) {
                    setCitaActual({
                      ...citaActual,
                      estado: value as "confirmada" | "pendiente" | "cancelada" | "completada",
                    })
                  }
                }}
              >
                <SelectTrigger id="estado">
                  <SelectValue placeholder="Seleccionar estado" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pendiente">Pendiente</SelectItem>
                  <SelectItem value="confirmada">Confirmada</SelectItem>
                  <SelectItem value="cancelada">Cancelada</SelectItem>
                  <SelectItem value="completada">Completada</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="notas">Notas</Label>
              <Textarea
                id="notas"
                placeholder="Notas adicionales sobre la cita..."
                value={citaActual?.notas || ""}
                onChange={(e) => {
                  if (citaActual) {
                    setCitaActual({ ...citaActual, notas: e.target.value })
                  }
                }}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalCita(false)}>
              Cancelar
            </Button>
            <Button
              onClick={() => {
                if (citaActual) {
                  modificarCita(citaActual)
                } else {
                  // Crear nueva cita con valores del formulario
                  const nuevaCita = {
                    clienteId: 1, // Valores por defecto que deberían ser reemplazados
                    servicioId: 1,
                    barberoId: 1,
                    fecha: format(fechaSeleccionada, "yyyy-MM-dd"),
                    hora: "10:00",
                    estado: "pendiente" as const,
                  }
                  crearCita(nuevaCita)
                }
              }}
              className="bg-amber-500 hover:bg-amber-600"
            >
              {citaActual ? "Guardar Cambios" : "Agendar Cita"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para transferir cita */}
      <Dialog open={modalTransferir} onOpenChange={setModalTransferir}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Transferir Cita</DialogTitle>
            <DialogDescription>Selecciona el barbero al que deseas transferir esta cita</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {citaActual && (
              <div className="mb-4 rounded-lg border p-4">
                <div className="font-medium">
                  Cliente: {clientes.find((c) => c.id === citaActual.clienteId)?.nombre}
                </div>
                <div className="text-sm text-muted-foreground">
                  {format(parseISO(citaActual.fecha), "PPP", { locale: es })} a las {citaActual.hora}
                </div>
                <div className="mt-2 text-sm">
                  Barbero actual: {barberos.find((b) => b.id === citaActual.barberoId)?.nombre}
                </div>
              </div>
            )}
            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="nuevoBarbero">Nuevo Barbero</Label>
                <Select value={nuevoBarberoId} onValueChange={setNuevoBarberoId}>
                  <SelectTrigger id="nuevoBarbero">
                    <SelectValue placeholder="Seleccionar barbero" />
                  </SelectTrigger>
                  <SelectContent>
                    {barberos
                      .filter((b) => b.id !== citaActual?.barberoId)
                      .map((barbero) => (
                        <SelectItem key={barbero.id} value={barbero.id.toString()}>
                          {barbero.nombre}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalTransferir(false)}>
              Cancelar
            </Button>
            <Button
              onClick={() => {
                if (citaActual && nuevoBarberoId) {
                  transferirCita(citaActual.id, Number(nuevoBarberoId))
                }
              }}
              disabled={!nuevoBarberoId}
              className="bg-amber-500 hover:bg-amber-600"
            >
              Transferir
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para cancelar cita */}
      <Dialog open={modalCancelar} onOpenChange={setModalCancelar}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Cancelar Cita</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas cancelar esta cita? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {citaActual && (
              <div className="rounded-lg border p-4">
                <div className="font-medium">
                  Cliente: {clientes.find((c) => c.id === citaActual.clienteId)?.nombre}
                </div>
                <div className="text-sm text-muted-foreground">
                  {format(parseISO(citaActual.fecha), "PPP", { locale: es })} a las {citaActual.hora}
                </div>
                <div className="mt-2 text-sm">
                  Servicio: {servicios.find((s) => s.id === citaActual.servicioId)?.nombre}
                </div>
                <div className="text-sm">Barbero: {barberos.find((b) => b.id === citaActual.barberoId)?.nombre}</div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalCancelar(false)}>
              Volver
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                if (citaActual) {
                  cancelarCita(citaActual.id)
                }
              }}
            >
              Cancelar Cita
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
