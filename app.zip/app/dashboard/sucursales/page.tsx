"use client"

import { useState } from "react"
import { format, parseISO } from "date-fns"
import { es } from "date-fns/locale"
import { Building, Calendar, Edit, MapPin, MoreVertical, Phone, Plus, Scissors, Trash2, Users } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Tipos
interface Sucursal {
  id: number
  nombre: string
  direccion: string
  telefono: string
  email: string
  horarioApertura: string
  horarioCierre: string
  diasOperativos: string[]
  activa: boolean
  fechaApertura: string
  responsable: string
  imagen: string
}

interface Empleado {
  id: number
  nombre: string
  apellido: string
  rol: string
  telefono: string
  email: string
  activo: boolean
}

interface AsignacionPersonal {
  id: number
  sucursalId: number
  empleadoId: number
  rol: string
  horarioInicio: string
  horarioFin: string
  diasTrabajo: string[]
}

interface Servicio {
  id: number
  nombre: string
  duracion: number
  precio: number
}

interface ServicioSucursal {
  id: number
  sucursalId: number
  servicioId: number
  precio: number
  disponible: boolean
}

// Datos de ejemplo
const sucursalesIniciales: Sucursal[] = [
  {
    id: 1,
    nombre: "El Filo - Centro",
    direccion: "Av. Principal 123, Centro",
    telefono: "555-1234",
    email: "centro@elfilo.com",
    horarioApertura: "09:00",
    horarioCierre: "20:00",
    diasOperativos: ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"],
    activa: true,
    fechaApertura: "2022-01-15",
    responsable: "Juan Pérez",
    imagen: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 2,
    nombre: "El Filo - Norte",
    direccion: "Plaza Comercial Norte, Local 45",
    telefono: "555-5678",
    email: "norte@elfilo.com",
    horarioApertura: "10:00",
    horarioCierre: "21:00",
    diasOperativos: ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"],
    activa: true,
    fechaApertura: "2023-03-10",
    responsable: "Miguel Rodríguez",
    imagen: "/placeholder.svg?height=200&width=300",
  },
  {
    id: 3,
    nombre: "El Filo - Sur",
    direccion: "Calzada del Sur 789",
    telefono: "555-9012",
    email: "sur@elfilo.com",
    horarioApertura: "09:00",
    horarioCierre: "19:00",
    diasOperativos: ["Martes", "Miércoles", "Jueves", "Viernes", "Sábado"],
    activa: true,
    fechaApertura: "2023-07-22",
    responsable: "Carlos Sánchez",
    imagen: "/placeholder.svg?height=200&width=300",
  },
]

const empleadosIniciales: Empleado[] = [
  {
    id: 1,
    nombre: "Juan",
    apellido: "Pérez",
    rol: "Barbero",
    telefono: "555-1234",
    email: "juan@elfilo.com",
    activo: true,
  },
  {
    id: 2,
    nombre: "Miguel",
    apellido: "Rodríguez",
    rol: "Barbero",
    telefono: "555-5678",
    email: "miguel@elfilo.com",
    activo: true,
  },
  {
    id: 3,
    nombre: "Carlos",
    apellido: "Sánchez",
    rol: "Barbero",
    telefono: "555-9012",
    email: "carlos@elfilo.com",
    activo: true,
  },
  {
    id: 4,
    nombre: "Ana",
    apellido: "Martínez",
    rol: "Recepcionista",
    telefono: "555-3456",
    email: "ana@elfilo.com",
    activo: true,
  },
  {
    id: 5,
    nombre: "Luis",
    apellido: "Gómez",
    rol: "Limpieza",
    telefono: "555-7890",
    email: "luis@elfilo.com",
    activo: true,
  },
  {
    id: 6,
    nombre: "Roberto",
    apellido: "Fernández",
    rol: "Barbero",
    telefono: "555-2468",
    email: "roberto@elfilo.com",
    activo: true,
  },
  {
    id: 7,
    nombre: "María",
    apellido: "López",
    rol: "Recepcionista",
    telefono: "555-1357",
    email: "maria@elfilo.com",
    activo: true,
  },
]

const serviciosIniciales: Servicio[] = [
  { id: 1, nombre: "Corte de cabello", duracion: 30, precio: 150 },
  { id: 2, nombre: "Afeitado tradicional", duracion: 25, precio: 120 },
  { id: 3, nombre: "Corte y barba", duracion: 45, precio: 250 },
  { id: 4, nombre: "Fade", duracion: 35, precio: 180 },
  { id: 5, nombre: "Lavado y peinado", duracion: 20, precio: 100 },
  { id: 6, nombre: "Tratamiento capilar", duracion: 40, precio: 300 },
]

// Generar asignaciones de personal
const generarAsignacionesIniciales = (): AsignacionPersonal[] => {
  const asignaciones: AsignacionPersonal[] = [
    {
      id: 1,
      sucursalId: 1,
      empleadoId: 1,
      rol: "Barbero",
      horarioInicio: "09:00",
      horarioFin: "17:00",
      diasTrabajo: ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"],
    },
    {
      id: 2,
      sucursalId: 1,
      empleadoId: 4,
      rol: "Recepcionista",
      horarioInicio: "09:00",
      horarioFin: "17:00",
      diasTrabajo: ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"],
    },
    {
      id: 3,
      sucursalId: 1,
      empleadoId: 5,
      rol: "Limpieza",
      horarioInicio: "08:00",
      horarioFin: "12:00",
      diasTrabajo: ["Lunes", "Miércoles", "Viernes"],
    },
    {
      id: 4,
      sucursalId: 2,
      empleadoId: 2,
      rol: "Barbero",
      horarioInicio: "10:00",
      horarioFin: "18:00",
      diasTrabajo: ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"],
    },
    {
      id: 5,
      sucursalId: 2,
      empleadoId: 6,
      rol: "Barbero",
      horarioInicio: "13:00",
      horarioFin: "21:00",
      diasTrabajo: ["Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"],
    },
    {
      id: 6,
      sucursalId: 2,
      empleadoId: 7,
      rol: "Recepcionista",
      horarioInicio: "10:00",
      horarioFin: "18:00",
      diasTrabajo: ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"],
    },
    {
      id: 7,
      sucursalId: 3,
      empleadoId: 3,
      rol: "Barbero",
      horarioInicio: "09:00",
      horarioFin: "17:00",
      diasTrabajo: ["Martes", "Miércoles", "Jueves", "Viernes", "Sábado"],
    },
  ]

  return asignaciones
}

// Generar servicios por sucursal
const generarServiciosSucursal = (): ServicioSucursal[] => {
  const serviciosSucursal: ServicioSucursal[] = []
  let id = 1

  // Para cada sucursal, asignar todos los servicios con pequeñas variaciones de precio
  sucursalesIniciales.forEach((sucursal) => {
    serviciosIniciales.forEach((servicio) => {
      // Variación de precio: -10% a +10% del precio base
      const variacion = Math.random() * 0.2 - 0.1
      const precio = Math.round(servicio.precio * (1 + variacion))

      serviciosSucursal.push({
        id: id++,
        sucursalId: sucursal.id,
        servicioId: servicio.id,
        precio: precio,
        disponible: Math.random() > 0.1, // 90% de probabilidad de estar disponible
      })
    })
  })

  return serviciosSucursal
}

const asignacionesIniciales = generarAsignacionesIniciales()
const serviciosSucursalIniciales = generarServiciosSucursal()

export default function SucursalesPage() {
  // Estados
  const [sucursales, setSucursales] = useState<Sucursal[]>(sucursalesIniciales)
  const [empleados] = useState<Empleado[]>(empleadosIniciales)
  const [servicios] = useState<Servicio[]>(serviciosIniciales)
  const [asignaciones, setAsignaciones] = useState<AsignacionPersonal[]>(asignacionesIniciales)
  const [serviciosSucursal, setServiciosSucursal] = useState<ServicioSucursal[]>(serviciosSucursalIniciales)

  const [sucursalActual, setSucursalActual] = useState<Sucursal | null>(null)
  const [modalSucursal, setModalSucursal] = useState(false)
  const [modalEliminar, setModalEliminar] = useState(false)
  const [modalAsignarPersonal, setModalAsignarPersonal] = useState(false)
  const [modalServicios, setModalServicios] = useState(false)
  const [modalDetalles, setModalDetalles] = useState(false)

  const [empleadosSeleccionados, setEmpleadosSeleccionados] = useState<number[]>([])
  const [serviciosSeleccionados, setServiciosSeleccionados] = useState<{
    [key: number]: { disponible: boolean; precio: number }
  }>({})

  // Toast para notificaciones
  const { toast } = useToast()

  // Función para abrir el modal de nueva sucursal
  const abrirNuevaSucursal = () => {
    setSucursalActual(null)
    setModalSucursal(true)
  }

  // Función para abrir el modal de edición de sucursal
  const abrirEditarSucursal = (sucursal: Sucursal) => {
    setSucursalActual({ ...sucursal })
    setModalSucursal(true)
  }

  // Función para abrir el modal de eliminación de sucursal
  const abrirEliminarSucursal = (sucursal: Sucursal) => {
    setSucursalActual(sucursal)
    setModalEliminar(true)
  }

  // Función para abrir el modal de detalles de sucursal
  const abrirDetallesSucursal = (sucursal: Sucursal) => {
    setSucursalActual(sucursal)
    setModalDetalles(true)
  }

  // Función para abrir el modal de asignación de personal
  const abrirAsignarPersonal = (sucursal: Sucursal) => {
    setSucursalActual(sucursal)

    // Preseleccionar empleados ya asignados a esta sucursal
    const empleadosAsignados = asignaciones.filter((a) => a.sucursalId === sucursal.id).map((a) => a.empleadoId)

    setEmpleadosSeleccionados(empleadosAsignados)
    setModalAsignarPersonal(true)
  }

  // Función para abrir el modal de configuración de servicios
  const abrirConfigurarServicios = (sucursal: Sucursal) => {
    setSucursalActual(sucursal)

    // Preseleccionar servicios ya configurados para esta sucursal
    const serviciosConfig: { [key: number]: { disponible: boolean; precio: number } } = {}

    serviciosSucursal
      .filter((s) => s.sucursalId === sucursal.id)
      .forEach((s) => {
        serviciosConfig[s.servicioId] = {
          disponible: s.disponible,
          precio: s.precio,
        }
      })

    setServiciosSeleccionados(serviciosConfig)
    setModalServicios(true)
  }

  // Función para guardar sucursal (crear o actualizar)
  const guardarSucursal = (sucursal: Sucursal) => {
    if (sucursalActual) {
      // Actualizar sucursal existente
      setSucursales(sucursales.map((s) => (s.id === sucursal.id ? sucursal : s)))
      toast({
        title: "Sucursal actualizada",
        description: `Se ha actualizado la información de ${sucursal.nombre}`,
      })
    } else {
      // Crear nueva sucursal
      const nuevaSucursal = {
        ...sucursal,
        id: Math.max(...sucursales.map((s) => s.id), 0) + 1,
      }
      setSucursales([...sucursales, nuevaSucursal])
      toast({
        title: "Sucursal agregada",
        description: `Se ha agregado ${sucursal.nombre} a la lista de sucursales`,
      })
    }
    setModalSucursal(false)
  }

  // Función para eliminar sucursal
  const eliminarSucursal = () => {
    if (sucursalActual) {
      // Eliminar sucursal
      setSucursales(sucursales.filter((s) => s.id !== sucursalActual.id))

      // Eliminar asignaciones de personal relacionadas
      setAsignaciones(asignaciones.filter((a) => a.sucursalId !== sucursalActual.id))

      // Eliminar servicios relacionados
      setServiciosSucursal(serviciosSucursal.filter((s) => s.sucursalId !== sucursalActual.id))

      toast({
        title: "Sucursal eliminada",
        description: `Se ha eliminado ${sucursalActual.nombre} y todos sus datos relacionados`,
        variant: "destructive",
      })
      setModalEliminar(false)
    }
  }

  // Función para guardar asignaciones de personal
  const guardarAsignacionesPersonal = () => {
    if (sucursalActual) {
      // Eliminar asignaciones anteriores para esta sucursal
      const asignacionesOtrasSucursales = asignaciones.filter((a) => a.sucursalId !== sucursalActual.id)

      // Crear nuevas asignaciones para los empleados seleccionados
      const nuevasAsignaciones = empleadosSeleccionados.map((empleadoId, index) => {
        const empleado = empleados.find((e) => e.id === empleadoId)
        return {
          id: Math.max(...asignaciones.map((a) => a.id), 0) + index + 1,
          sucursalId: sucursalActual.id,
          empleadoId,
          rol: empleado?.rol || "No especificado",
          horarioInicio: "09:00", // Valores por defecto
          horarioFin: "17:00",
          diasTrabajo: ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"],
        }
      })

      setAsignaciones([...asignacionesOtrasSucursales, ...nuevasAsignaciones])

      toast({
        title: "Personal asignado",
        description: `Se han asignado ${nuevasAsignaciones.length} empleados a ${sucursalActual.nombre}`,
      })
      setModalAsignarPersonal(false)
    }
  }

  // Función para guardar configuración de servicios
  const guardarConfiguracionServicios = () => {
    if (sucursalActual) {
      // Eliminar configuraciones anteriores para esta sucursal
      const serviciosOtrasSucursales = serviciosSucursal.filter((s) => s.sucursalId !== sucursalActual.id)

      // Crear nuevas configuraciones para los servicios seleccionados
      const nuevosServicios: ServicioSucursal[] = []

      Object.entries(serviciosSeleccionados).forEach(([servicioIdStr, config], index) => {
        const servicioId = Number.parseInt(servicioIdStr)
        nuevosServicios.push({
          id: Math.max(...serviciosSucursal.map((s) => s.id), 0) + index + 1,
          sucursalId: sucursalActual.id,
          servicioId,
          precio: config.precio,
          disponible: config.disponible,
        })
      })

      setServiciosSucursal([...serviciosOtrasSucursales, ...nuevosServicios])

      toast({
        title: "Servicios configurados",
        description: `Se han configurado ${nuevosServicios.length} servicios para ${sucursalActual.nombre}`,
      })
      setModalServicios(false)
    }
  }

  // Obtener empleados asignados a una sucursal
  const getEmpleadosPorSucursal = (sucursalId: number) => {
    const asignacionesSucursal = asignaciones.filter((a) => a.sucursalId === sucursalId)
    return asignacionesSucursal
      .map((a) => {
        const empleado = empleados.find((e) => e.id === a.empleadoId)
        return empleado ? { ...empleado, ...a } : null
      })
      .filter(Boolean)
  }

  // Obtener servicios configurados para una sucursal
  const getServiciosPorSucursal = (sucursalId: number) => {
    const serviciosSucursalFiltrados = serviciosSucursal.filter((s) => s.sucursalId === sucursalId)
    return serviciosSucursalFiltrados
      .map((s) => {
        const servicio = servicios.find((serv) => serv.id === s.servicioId)
        return servicio ? { ...servicio, ...s } : null
      })
      .filter(Boolean)
  }

  // Función para alternar la selección de un empleado
  const toggleEmpleadoSeleccionado = (empleadoId: number) => {
    setEmpleadosSeleccionados((prev) =>
      prev.includes(empleadoId) ? prev.filter((id) => id !== empleadoId) : [...prev, empleadoId],
    )
  }

  // Función para alternar la disponibilidad de un servicio
  const toggleServicioDisponible = (servicioId: number) => {
    setServiciosSeleccionados((prev) => {
      const current = prev[servicioId] || {
        disponible: true,
        precio: servicios.find((s) => s.id === servicioId)?.precio || 0,
      }
      return {
        ...prev,
        [servicioId]: {
          ...current,
          disponible: !current.disponible,
        },
      }
    })
  }

  // Función para actualizar el precio de un servicio
  const actualizarPrecioServicio = (servicioId: number, precio: number) => {
    setServiciosSeleccionados((prev) => {
      const current = prev[servicioId] || {
        disponible: true,
        precio: servicios.find((s) => s.id === servicioId)?.precio || 0,
      }
      return {
        ...prev,
        [servicioId]: {
          ...current,
          precio,
        },
      }
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Gestión de Sucursales</h1>
          <p className="text-muted-foreground">Administra las diferentes ubicaciones de Barbería "El Filo"</p>
        </div>
        <Button onClick={abrirNuevaSucursal} className="bg-amber-500 hover:bg-amber-600">
          <Plus className="mr-2 h-4 w-4" />
          Nueva Sucursal
        </Button>
      </div>

      <Tabs defaultValue="resumen" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="resumen">
            <Building className="mr-2 h-4 w-4" />
            Resumen
          </TabsTrigger>
          <TabsTrigger value="personal">
            <Users className="mr-2 h-4 w-4" />
            Personal
          </TabsTrigger>
          <TabsTrigger value="servicios">
            <Scissors className="mr-2 h-4 w-4" />
            Servicios
          </TabsTrigger>
        </TabsList>

        {/* Pestaña de Resumen */}
        <TabsContent value="resumen" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Resumen de Sucursales</CardTitle>
              <CardDescription>Vista general de todas las sucursales de Barbería "El Filo"</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                {sucursales.map((sucursal) => {
                  const empleadosAsignados = getEmpleadosPorSucursal(sucursal.id).length
                  const serviciosDisponibles = getServiciosPorSucursal(sucursal.id).filter((s) => s?.disponible).length

                  return (
                    <Card key={sucursal.id} className="overflow-hidden">
                      <div className="aspect-video w-full">
                        <img
                          src={sucursal.imagen || "/placeholder.svg"}
                          alt={sucursal.nombre}
                          className="h-full w-full object-cover"
                        />
                      </div>
                      <CardHeader className="p-4">
                        <div className="flex items-start justify-between">
                          <CardTitle className="text-xl">{sucursal.nombre}</CardTitle>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => abrirDetallesSucursal(sucursal)}>
                                Ver detalles
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => abrirEditarSucursal(sucursal)}>
                                <Edit className="mr-2 h-4 w-4" />
                                Editar
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => abrirAsignarPersonal(sucursal)}>
                                <Users className="mr-2 h-4 w-4" />
                                Asignar Personal
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => abrirConfigurarServicios(sucursal)}>
                                <Scissors className="mr-2 h-4 w-4" />
                                Configurar Servicios
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem
                                className="text-red-600"
                                onClick={() => abrirEliminarSucursal(sucursal)}
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Eliminar
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </CardHeader>
                      <CardContent className="p-4 pt-0">
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <span>{sucursal.direccion}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Phone className="h-4 w-4 text-muted-foreground" />
                            <span>{sucursal.telefono}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-muted-foreground" />
                            <span>
                              {sucursal.horarioApertura} - {sucursal.horarioCierre}
                            </span>
                          </div>
                        </div>
                        <div className="mt-4 flex items-center justify-between">
                          <div className="flex items-center gap-1">
                            <Users className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{empleadosAsignados} empleados</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Scissors className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">{serviciosDisponibles} servicios</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña de Personal */}
        <TabsContent value="personal" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Asignación de Personal</CardTitle>
              <CardDescription>Gestiona el personal asignado a cada sucursal</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {sucursales.map((sucursal) => {
                  const empleadosAsignados = getEmpleadosPorSucursal(sucursal.id)

                  return (
                    <div key={sucursal.id} className="rounded-lg border p-4">
                      <div className="mb-4 flex items-center justify-between">
                        <div>
                          <h3 className="text-lg font-medium">{sucursal.nombre}</h3>
                          <p className="text-sm text-muted-foreground">{sucursal.direccion}</p>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => abrirAsignarPersonal(sucursal)}
                          className="bg-amber-500 hover:bg-amber-600"
                        >
                          <Users className="mr-2 h-4 w-4" />
                          Asignar Personal
                        </Button>
                      </div>

                      {empleadosAsignados.length > 0 ? (
                        <div className="rounded-md border">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Nombre</TableHead>
                                <TableHead>Rol</TableHead>
                                <TableHead>Horario</TableHead>
                                <TableHead>Días</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {empleadosAsignados.map((empleado) => (
                                <TableRow key={empleado!.id}>
                                  <TableCell className="font-medium">
                                    {empleado!.nombre} {empleado!.apellido}
                                  </TableCell>
                                  <TableCell>{empleado!.rol}</TableCell>
                                  <TableCell>
                                    {empleado!.horarioInicio} - {empleado!.horarioFin}
                                  </TableCell>
                                  <TableCell>
                                    <div className="flex flex-wrap gap-1">
                                      {empleado!.diasTrabajo.map((dia) => (
                                        <Badge key={dia} variant="outline" className="text-xs">
                                          {dia.substring(0, 3)}
                                        </Badge>
                                      ))}
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      ) : (
                        <div className="rounded-lg border border-dashed p-4 text-center text-muted-foreground">
                          No hay personal asignado a esta sucursal
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña de Servicios */}
        <TabsContent value="servicios" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Servicios por Sucursal</CardTitle>
              <CardDescription>Configura los servicios disponibles en cada sucursal</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {sucursales.map((sucursal) => {
                  const serviciosSucursalActual = getServiciosPorSucursal(sucursal.id)

                  return (
                    <div key={sucursal.id} className="rounded-lg border p-4">
                      <div className="mb-4 flex items-center justify-between">
                        <div>
                          <h3 className="text-lg font-medium">{sucursal.nombre}</h3>
                          <p className="text-sm text-muted-foreground">{sucursal.direccion}</p>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => abrirConfigurarServicios(sucursal)}
                          className="bg-amber-500 hover:bg-amber-600"
                        >
                          <Scissors className="mr-2 h-4 w-4" />
                          Configurar Servicios
                        </Button>
                      </div>

                      {serviciosSucursalActual.length > 0 ? (
                        <div className="rounded-md border">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Servicio</TableHead>
                                <TableHead>Duración</TableHead>
                                <TableHead>Precio</TableHead>
                                <TableHead>Estado</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {serviciosSucursalActual.map((servicio) => (
                                <TableRow key={servicio!.id} className={!servicio!.disponible ? "opacity-60" : ""}>
                                  <TableCell className="font-medium">{servicio!.nombre}</TableCell>
                                  <TableCell>{servicio!.duracion} min</TableCell>
                                  <TableCell>${servicio!.precio.toFixed(2)}</TableCell>
                                  <TableCell>
                                    {servicio!.disponible ? (
                                      <Badge className="bg-green-100 text-green-800">Disponible</Badge>
                                    ) : (
                                      <Badge variant="outline" className="bg-gray-100">
                                        No disponible
                                      </Badge>
                                    )}
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      ) : (
                        <div className="rounded-lg border border-dashed p-4 text-center text-muted-foreground">
                          No hay servicios configurados para esta sucursal
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Modal para crear/editar sucursal */}
      <Dialog open={modalSucursal} onOpenChange={setModalSucursal}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{sucursalActual ? "Editar Sucursal" : "Nueva Sucursal"}</DialogTitle>
            <DialogDescription>
              {sucursalActual
                ? "Modifica los datos de la sucursal seleccionada"
                : "Completa los campos para agregar una nueva sucursal"}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="nombre">Nombre de la sucursal</Label>
              <Input id="nombre" defaultValue={sucursalActual?.nombre || ""} placeholder="Ej: El Filo - Centro" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="direccion">Dirección</Label>
              <Textarea
                id="direccion"
                defaultValue={sucursalActual?.direccion || ""}
                placeholder="Dirección completa de la sucursal"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="telefono">Teléfono</Label>
                <Input id="telefono" defaultValue={sucursalActual?.telefono || ""} placeholder="555-1234" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  defaultValue={sucursalActual?.email || ""}
                  placeholder="sucursal@elfilo.com"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="horarioApertura">Horario de apertura</Label>
                <Input id="horarioApertura" type="time" defaultValue={sucursalActual?.horarioApertura || "09:00"} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="horarioCierre">Horario de cierre</Label>
                <Input id="horarioCierre" type="time" defaultValue={sucursalActual?.horarioCierre || "20:00"} />
              </div>
            </div>
            <div className="grid gap-2">
              <Label>Días operativos</Label>
              <div className="flex flex-wrap gap-2">
                {["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"].map((dia) => (
                  <div key={dia} className="flex items-center space-x-2">
                    <Checkbox id={`dia-${dia}`} defaultChecked={sucursalActual?.diasOperativos.includes(dia)} />
                    <Label htmlFor={`dia-${dia}`} className="text-sm font-normal">
                      {dia}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="fechaApertura">Fecha de apertura</Label>
                <Input
                  id="fechaApertura"
                  type="date"
                  defaultValue={sucursalActual?.fechaApertura || format(new Date(), "yyyy-MM-dd")}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="responsable">Responsable</Label>
                <Input
                  id="responsable"
                  defaultValue={sucursalActual?.responsable || ""}
                  placeholder="Nombre del responsable"
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="imagen">URL de imagen</Label>
              <Input
                id="imagen"
                defaultValue={sucursalActual?.imagen || "/placeholder.svg?height=200&width=300"}
                placeholder="URL de la imagen de la sucursal"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalSucursal(false)}>
              Cancelar
            </Button>
            <Button
              onClick={() => {
                // Aquí se recogerían los valores del formulario
                // Por simplicidad, usamos valores de ejemplo
                const nuevaSucursal: Sucursal = {
                  id: sucursalActual?.id || 0,
                  nombre: "Nueva Sucursal",
                  direccion: "Dirección de ejemplo",
                  telefono: "555-0000",
                  email: "nueva@elfilo.com",
                  horarioApertura: "09:00",
                  horarioCierre: "20:00",
                  diasOperativos: ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes"],
                  activa: true,
                  fechaApertura: format(new Date(), "yyyy-MM-dd"),
                  responsable: "Nuevo Responsable",
                  imagen: "/placeholder.svg?height=200&width=300",
                }
                guardarSucursal(nuevaSucursal)
              }}
              className="bg-amber-500 hover:bg-amber-600"
            >
              {sucursalActual ? "Guardar Cambios" : "Crear Sucursal"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para eliminar sucursal */}
      <Dialog open={modalEliminar} onOpenChange={setModalEliminar}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Eliminar Sucursal</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas eliminar esta sucursal? Esta acción eliminará todos los datos relacionados y
              no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {sucursalActual && (
              <div className="rounded-lg border p-4">
                <h3 className="font-medium">{sucursalActual.nombre}</h3>
                <p className="text-sm text-muted-foreground">{sucursalActual.direccion}</p>
                <div className="mt-2 text-sm">
                  <span className="text-red-600 font-medium">
                    Se eliminarán también {getEmpleadosPorSucursal(sucursalActual.id).length} asignaciones de personal y{" "}
                    {getServiciosPorSucursal(sucursalActual.id).length} configuraciones de servicios.
                  </span>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalEliminar(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={eliminarSucursal}>
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para asignar personal */}
      <Dialog open={modalAsignarPersonal} onOpenChange={setModalAsignarPersonal}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Asignar Personal</DialogTitle>
            <DialogDescription>Selecciona los empleados que trabajarán en {sucursalActual?.nombre}</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="max-h-[400px] overflow-y-auto rounded-md border p-4">
              <div className="space-y-4">
                {empleados
                  .filter((e) => e.activo)
                  .map((empleado) => (
                    <div key={empleado.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`empleado-${empleado.id}`}
                        checked={empleadosSeleccionados.includes(empleado.id)}
                        onCheckedChange={() => toggleEmpleadoSeleccionado(empleado.id)}
                      />
                      <Label htmlFor={`empleado-${empleado.id}`} className="flex flex-1 items-center justify-between">
                        <span>
                          {empleado.nombre} {empleado.apellido}
                        </span>
                        <Badge>{empleado.rol}</Badge>
                      </Label>
                    </div>
                  ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalAsignarPersonal(false)}>
              Cancelar
            </Button>
            <Button onClick={guardarAsignacionesPersonal} className="bg-amber-500 hover:bg-amber-600">
              Guardar Asignaciones
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para configurar servicios */}
      <Dialog open={modalServicios} onOpenChange={setModalServicios}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Configurar Servicios</DialogTitle>
            <DialogDescription>
              Configura los servicios disponibles en {sucursalActual?.nombre} y sus precios
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="max-h-[400px] overflow-y-auto rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Servicio</TableHead>
                    <TableHead>Duración</TableHead>
                    <TableHead>Precio</TableHead>
                    <TableHead>Disponible</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {servicios.map((servicio) => {
                    const config = serviciosSeleccionados[servicio.id] || {
                      disponible: true,
                      precio: servicio.precio,
                    }

                    return (
                      <TableRow key={servicio.id} className={!config.disponible ? "opacity-60" : ""}>
                        <TableCell className="font-medium">{servicio.nombre}</TableCell>
                        <TableCell>{servicio.duracion} min</TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            value={config.precio}
                            onChange={(e) => actualizarPrecioServicio(servicio.id, Number(e.target.value))}
                            className="w-20"
                            min={0}
                          />
                        </TableCell>
                        <TableCell>
                          <Checkbox
                            checked={config.disponible}
                            onCheckedChange={() => toggleServicioDisponible(servicio.id)}
                          />
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalServicios(false)}>
              Cancelar
            </Button>
            <Button onClick={guardarConfiguracionServicios} className="bg-amber-500 hover:bg-amber-600">
              Guardar Configuración
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para ver detalles de sucursal */}
      <Dialog open={modalDetalles} onOpenChange={setModalDetalles}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle>Detalles de Sucursal</DialogTitle>
            <DialogDescription>Información detallada sobre {sucursalActual?.nombre}</DialogDescription>
          </DialogHeader>
          {sucursalActual && (
            <div className="py-4">
              <div className="mb-6 aspect-video w-full overflow-hidden rounded-lg">
                <img
                  src={sucursalActual.imagen || "/placeholder.svg"}
                  alt={sucursalActual.nombre}
                  className="h-full w-full object-cover"
                />
              </div>

              <div className="grid gap-6 md:grid-cols-2">
                <div>
                  <h3 className="mb-2 font-semibold">Información General</h3>
                  <div className="space-y-2 rounded-lg border p-4">
                    <div className="grid grid-cols-3 gap-1">
                      <span className="text-sm font-medium">Nombre:</span>
                      <span className="col-span-2 text-sm">{sucursalActual.nombre}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-1">
                      <span className="text-sm font-medium">Dirección:</span>
                      <span className="col-span-2 text-sm">{sucursalActual.direccion}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-1">
                      <span className="text-sm font-medium">Teléfono:</span>
                      <span className="col-span-2 text-sm">{sucursalActual.telefono}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-1">
                      <span className="text-sm font-medium">Email:</span>
                      <span className="col-span-2 text-sm">{sucursalActual.email}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-1">
                      <span className="text-sm font-medium">Responsable:</span>
                      <span className="col-span-2 text-sm">{sucursalActual.responsable}</span>
                    </div>
                    <div className="grid grid-cols-3 gap-1">
                      <span className="text-sm font-medium">Apertura:</span>
                      <span className="col-span-2 text-sm">
                        {format(parseISO(sucursalActual.fechaApertura), "PPP", { locale: es })}
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="mb-2 font-semibold">Horarios</h3>
                  <div className="space-y-2 rounded-lg border p-4">
                    <div className="grid grid-cols-3 gap-1">
                      <span className="text-sm font-medium">Horario:</span>
                      <span className="col-span-2 text-sm">
                        {sucursalActual.horarioApertura} - {sucursalActual.horarioCierre}
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-1">
                      <span className="text-sm font-medium">Días:</span>
                      <div className="col-span-2 flex flex-wrap gap-1">
                        {sucursalActual.diasOperativos.map((dia) => (
                          <Badge key={dia} variant="outline" className="text-xs">
                            {dia}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>

                  <h3 className="mb-2 mt-4 font-semibold">Estadísticas</h3>
                  <div className="space-y-2 rounded-lg border p-4">
                    <div className="grid grid-cols-3 gap-1">
                      <span className="text-sm font-medium">Personal:</span>
                      <span className="col-span-2 text-sm">
                        {getEmpleadosPorSucursal(sucursalActual.id).length} empleados asignados
                      </span>
                    </div>
                    <div className="grid grid-cols-3 gap-1">
                      <span className="text-sm font-medium">Servicios:</span>
                      <span className="col-span-2 text-sm">
                        {getServiciosPorSucursal(sucursalActual.id).filter((s) => s?.disponible).length} servicios
                        disponibles
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-2">
                <Button variant="outline" onClick={() => setModalDetalles(false)}>
                  Cerrar
                </Button>
                <Button
                  onClick={() => {
                    setModalDetalles(false)
                    abrirEditarSucursal(sucursalActual)
                  }}
                  className="bg-amber-500 hover:bg-amber-600"
                >
                  <Edit className="mr-2 h-4 w-4" />
                  Editar
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
