"use client"

import { useState } from "react"
import { format, parseISO, subDays } from "date-fns"
import {
  AlertCircle,
  ArrowDownCircle,
  ArrowUpCircle,
  BarChart3,
  Edit,
  ImageIcon,
  MoreVertical,
  Package,
  Plus,
  Search,
  Trash2,
} from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Tipos
interface Producto {
  id: number
  nombre: string
  descripcion: string
  categoria: string
  precio: number
  existencias: number
  umbralMinimo: number
  imagen: string
  proveedor: string
  activo: boolean
}

interface MovimientoInventario {
  id: number
  productoId: number
  tipo: "entrada" | "salida"
  cantidad: number
  motivo: string
  fecha: string
  usuario: string
}

interface Proveedor {
  id: number
  nombre: string
  telefono: string
  email: string
}

// Datos de ejemplo
const productosIniciales: Producto[] = [
  {
    id: 1,
    nombre: "Gel para cabello",
    descripcion: "Gel fijador de cabello con fijación extra fuerte",
    categoria: "Productos para cabello",
    precio: 120,
    existencias: 15,
    umbralMinimo: 10,
    imagen: "/placeholder.svg?height=100&width=100",
    proveedor: "Distribuidora de Belleza S.A.",
    activo: true,
  },
  {
    id: 2,
    nombre: "Cera para barba",
    descripcion: "Cera modeladora para barba con aceites esenciales",
    categoria: "Productos para barba",
    precio: 150,
    existencias: 8,
    umbralMinimo: 10,
    imagen: "/placeholder.svg?height=100&width=100",
    proveedor: "Barber Supplies Inc.",
    activo: true,
  },
  {
    id: 3,
    nombre: "Shampoo para hombre",
    descripcion: "Shampoo especial para cabello masculino con aroma a menta",
    categoria: "Productos para cabello",
    precio: 180,
    existencias: 20,
    umbralMinimo: 15,
    imagen: "/placeholder.svg?height=100&width=100",
    proveedor: "Distribuidora de Belleza S.A.",
    activo: true,
  },
  {
    id: 4,
    nombre: "Tijeras profesionales",
    descripcion: "Tijeras de acero inoxidable para corte profesional",
    categoria: "Herramientas",
    precio: 850,
    existencias: 5,
    umbralMinimo: 3,
    imagen: "/placeholder.svg?height=100&width=100",
    proveedor: "Barber Tools Co.",
    activo: true,
  },
  {
    id: 5,
    nombre: "Máquina de corte",
    descripcion: "Máquina de corte profesional con 5 niveles de corte",
    categoria: "Herramientas",
    precio: 1200,
    existencias: 3,
    umbralMinimo: 2,
    imagen: "/placeholder.svg?height=100&width=100",
    proveedor: "Barber Tools Co.",
    activo: true,
  },
  {
    id: 6,
    nombre: "Toallas desechables",
    descripcion: "Paquete de 100 toallas desechables para barbería",
    categoria: "Desechables",
    precio: 250,
    existencias: 12,
    umbralMinimo: 10,
    imagen: "/placeholder.svg?height=100&width=100",
    proveedor: "Suministros Generales",
    activo: true,
  },
  {
    id: 7,
    nombre: "Loción post-afeitado",
    descripcion: "Loción refrescante para después del afeitado",
    categoria: "Productos para barba",
    precio: 160,
    existencias: 18,
    umbralMinimo: 12,
    imagen: "/placeholder.svg?height=100&width=100",
    proveedor: "Barber Supplies Inc.",
    activo: true,
  },
  {
    id: 8,
    nombre: "Capas para corte",
    descripcion: "Capas impermeables para corte de cabello",
    categoria: "Accesorios",
    precio: 200,
    existencias: 25,
    umbralMinimo: 15,
    imagen: "/placeholder.svg?height=100&width=100",
    proveedor: "Suministros Generales",
    activo: true,
  },
]

const proveedoresIniciales: Proveedor[] = [
  {
    id: 1,
    nombre: "Distribuidora de Belleza S.A.",
    telefono: "555-1234",
    email: "contacto@distribelleza.com",
  },
  {
    id: 2,
    nombre: "Barber Supplies Inc.",
    telefono: "555-5678",
    email: "ventas@barbersupplies.com",
  },
  {
    id: 3,
    nombre: "Barber Tools Co.",
    telefono: "555-9012",
    email: "info@barbertools.com",
  },
  {
    id: 4,
    nombre: "Suministros Generales",
    telefono: "555-3456",
    email: "pedidos@suministrosgenerales.com",
  },
]

// Generar movimientos de inventario de ejemplo
const generarMovimientosIniciales = (): MovimientoInventario[] => {
  const movimientos: MovimientoInventario[] = []
  const hoy = new Date()
  const usuarios = ["Juan Díaz", "Ana Martínez", "Carlos Sánchez"]
  const motivos = [
    "Compra a proveedor",
    "Venta a cliente",
    "Uso interno",
    "Ajuste de inventario",
    "Devolución",
    "Producto dañado",
  ]

  // Generar 50 movimientos aleatorios en los últimos 30 días
  for (let i = 1; i <= 50; i++) {
    const productoId = Math.floor(Math.random() * productosIniciales.length) + 1
    const tipo = Math.random() > 0.4 ? "entrada" : "salida"
    const cantidad = Math.floor(Math.random() * 10) + 1
    const diasAtras = Math.floor(Math.random() * 30)
    const fecha = format(subDays(hoy, diasAtras), "yyyy-MM-dd")
    const usuario = usuarios[Math.floor(Math.random() * usuarios.length)]
    const motivo = motivos[Math.floor(Math.random() * motivos.length)]

    movimientos.push({
      id: i,
      productoId,
      tipo,
      cantidad,
      motivo,
      fecha,
      usuario,
    })
  }

  // Ordenar por fecha, más reciente primero
  return movimientos.sort((a, b) => {
    return parseISO(b.fecha).getTime() - parseISO(a.fecha).getTime()
  })
}

const movimientosIniciales = generarMovimientosIniciales()

export default function InventarioPage() {
  // Estados
  const [productos, setProductos] = useState<Producto[]>(productosIniciales)
  const [movimientos, setMovimientos] = useState<MovimientoInventario[]>(movimientosIniciales)
  const [proveedores] = useState<Proveedor[]>(proveedoresIniciales)
  const [productoActual, setProductoActual] = useState<Producto | null>(null)
  const [modalProducto, setModalProducto] = useState(false)
  const [modalEliminar, setModalEliminar] = useState(false)
  const [modalMovimiento, setModalMovimiento] = useState(false)
  const [vistaProductos, setVistaProductos] = useState<"tabla" | "miniaturas">("tabla")
  const [busqueda, setBusqueda] = useState("")
  const [filtroCategoria, setFiltroCategoria] = useState<string>("todas")

  // Toast para notificaciones
  const { toast } = useToast()

  // Filtrar productos
  const productosFiltrados = productos.filter((producto) => {
    const coincideBusqueda =
      producto.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
      producto.descripcion.toLowerCase().includes(busqueda.toLowerCase())

    const coincideCategoria = filtroCategoria === "todas" || producto.categoria === filtroCategoria

    return coincideBusqueda && coincideCategoria && producto.activo
  })

  // Obtener categorías únicas
  const categorias = Array.from(new Set(productos.map((p) => p.categoria)))

  // Función para abrir el modal de nuevo producto
  const abrirNuevoProducto = () => {
    setProductoActual(null)
    setModalProducto(true)
  }

  // Función para abrir el modal de edición de producto
  const abrirEditarProducto = (producto: Producto) => {
    setProductoActual({ ...producto })
    setModalProducto(true)
  }

  // Función para abrir el modal de eliminación de producto
  const abrirEliminarProducto = (producto: Producto) => {
    setProductoActual(producto)
    setModalEliminar(true)
  }

  // Función para guardar producto (crear o actualizar)
  const guardarProducto = (producto: Producto) => {
    if (productoActual) {
      // Actualizar producto existente
      setProductos(productos.map((p) => (p.id === producto.id ? producto : p)))
      toast({
        title: "Producto actualizado",
        description: `Se ha actualizado la información de ${producto.nombre}`,
      })
    } else {
      // Crear nuevo producto
      const nuevoProducto = {
        ...producto,
        id: Math.max(...productos.map((p) => p.id), 0) + 1,
      }
      setProductos([...productos, nuevoProducto])
      toast({
        title: "Producto agregado",
        description: `Se ha agregado ${producto.nombre} al inventario`,
      })
    }
    setModalProducto(false)
  }

  // Función para eliminar producto
  const eliminarProducto = () => {
    if (productoActual) {
      // Marcar como inactivo en lugar de eliminar completamente
      setProductos(productos.map((p) => (p.id === productoActual.id ? { ...p, activo: false } : p)))
      toast({
        title: "Producto eliminado",
        description: `Se ha eliminado ${productoActual.nombre} del inventario`,
        variant: "destructive",
      })
      setModalEliminar(false)
    }
  }

  // Función para abrir el modal de movimiento de inventario
  const abrirMovimientoInventario = (producto: Producto) => {
    setProductoActual(producto)
    setModalMovimiento(true)
  }

  // Función para registrar movimiento de inventario
  const registrarMovimiento = (movimiento: Omit<MovimientoInventario, "id" | "fecha" | "usuario">) => {
    if (productoActual) {
      // Crear nuevo movimiento
      const nuevoMovimiento: MovimientoInventario = {
        ...movimiento,
        id: Math.max(...movimientos.map((m) => m.id), 0) + 1,
        fecha: format(new Date(), "yyyy-MM-dd"),
        usuario: "Juan Díaz", // Usuario actual (hardcoded para el ejemplo)
      }

      // Actualizar existencias del producto
      const nuevasExistencias =
        movimiento.tipo === "entrada"
          ? productoActual.existencias + movimiento.cantidad
          : productoActual.existencias - movimiento.cantidad

      // Validar que no queden existencias negativas
      if (movimiento.tipo === "salida" && nuevasExistencias < 0) {
        toast({
          title: "Error en el movimiento",
          description: "No hay suficientes existencias para realizar esta salida",
          variant: "destructive",
        })
        return
      }

      // Actualizar producto
      const productoActualizado = {
        ...productoActual,
        existencias: nuevasExistencias,
      }

      setProductos(productos.map((p) => (p.id === productoActual.id ? productoActualizado : p)))
      setMovimientos([nuevoMovimiento, ...movimientos])

      toast({
        title: "Movimiento registrado",
        description: `Se ha registrado ${
          movimiento.tipo === "entrada" ? "la entrada" : "la salida"
        } de ${movimiento.cantidad} unidades de ${productoActual.nombre}`,
      })

      // Verificar si el producto está por debajo del umbral mínimo
      if (nuevasExistencias <= productoActual.umbralMinimo) {
        toast({
          title: "Alerta de inventario",
          description: `El producto ${productoActual.nombre} está por debajo del umbral mínimo (${productoActual.umbralMinimo})`,
          variant: "destructive",
        })
      }

      setModalMovimiento(false)
    }
  }

  // Obtener movimientos por producto
  const getMovimientosPorProducto = (productoId: number) => {
    return movimientos.filter((movimiento) => movimiento.productoId === productoId)
  }

  // Obtener nombre de producto por ID
  const getNombreProducto = (productoId: number) => {
    return productos.find((p) => p.id === productoId)?.nombre || "Producto desconocido"
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Gestión de Inventario</h1>
        <p className="text-muted-foreground">Administra el stock de productos y registra movimientos</p>
      </div>

      <Tabs defaultValue="productos" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="productos">
            <Package className="mr-2 h-4 w-4" />
            Productos
          </TabsTrigger>
          <TabsTrigger value="movimientos">
            <BarChart3 className="mr-2 h-4 w-4" />
            Movimientos de Inventario
          </TabsTrigger>
        </TabsList>

        {/* Pestaña de Productos */}
        <TabsContent value="productos" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Gestión de Productos</CardTitle>
                <CardDescription>Administra el catálogo de productos del inventario</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setVistaProductos(vistaProductos === "tabla" ? "miniaturas" : "tabla")}
                >
                  {vistaProductos === "tabla" ? (
                    <>
                      <ImageIcon className="mr-2 h-4 w-4" />
                      Ver miniaturas
                    </>
                  ) : (
                    <>
                      <Package className="mr-2 h-4 w-4" />
                      Ver tabla
                    </>
                  )}
                </Button>
                <Button onClick={abrirNuevoProducto} className="bg-amber-500 hover:bg-amber-600">
                  <Plus className="mr-2 h-4 w-4" />
                  Agregar Producto
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="mb-6 flex flex-col gap-4 sm:flex-row">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar productos..."
                    className="pl-8"
                    value={busqueda}
                    onChange={(e) => setBusqueda(e.target.value)}
                  />
                </div>
                <Select value={filtroCategoria} onValueChange={setFiltroCategoria}>
                  <SelectTrigger className="w-full sm:w-[200px]">
                    <SelectValue placeholder="Filtrar por categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todas">Todas las categorías</SelectItem>
                    {categorias.map((categoria) => (
                      <SelectItem key={categoria} value={categoria}>
                        {categoria}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {vistaProductos === "tabla" ? (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Nombre</TableHead>
                        <TableHead>Descripción</TableHead>
                        <TableHead>Precio</TableHead>
                        <TableHead>Existencias</TableHead>
                        <TableHead className="text-right">Acciones</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {productosFiltrados.length > 0 ? (
                        productosFiltrados.map((producto) => (
                          <TableRow key={producto.id}>
                            <TableCell className="font-medium">{producto.id}</TableCell>
                            <TableCell>{producto.nombre}</TableCell>
                            <TableCell className="max-w-xs truncate">{producto.descripcion}</TableCell>
                            <TableCell>${producto.precio.toFixed(2)}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <span
                                  className={
                                    producto.existencias <= producto.umbralMinimo ? "text-red-500 font-medium" : ""
                                  }
                                >
                                  {producto.existencias}
                                </span>
                                {producto.existencias <= producto.umbralMinimo && (
                                  <AlertCircle className="h-4 w-4 text-red-500" />
                                )}
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreVertical className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => abrirEditarProducto(producto)}>
                                    <Edit className="mr-2 h-4 w-4" />
                                    Editar
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => abrirMovimientoInventario(producto)}>
                                    <BarChart3 className="mr-2 h-4 w-4" />
                                    Registrar Movimiento
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    className="text-red-600"
                                    onClick={() => abrirEliminarProducto(producto)}
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Eliminar
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={6} className="h-24 text-center">
                            No se encontraron productos
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                  {productosFiltrados.length > 0 ? (
                    productosFiltrados.map((producto) => (
                      <div key={producto.id} className="rounded-lg border p-4">
                        <div className="mb-3 flex justify-center">
                          <img
                            src={producto.imagen || "/placeholder.svg"}
                            alt={producto.nombre}
                            className="h-32 w-32 rounded-md object-cover"
                          />
                        </div>
                        <h3 className="mb-1 font-medium">{producto.nombre}</h3>
                        <p className="mb-2 text-sm text-muted-foreground line-clamp-2">{producto.descripcion}</p>
                        <div className="mb-2 flex items-center justify-between">
                          <span className="font-medium">${producto.precio.toFixed(2)}</span>
                          <Badge>{producto.categoria}</Badge>
                        </div>
                        <div className="mb-3 flex items-center justify-between">
                          <div className="flex items-center gap-1">
                            <span
                              className={
                                producto.existencias <= producto.umbralMinimo ? "text-red-500 font-medium" : ""
                              }
                            >
                              Stock: {producto.existencias}
                            </span>
                            {producto.existencias <= producto.umbralMinimo && (
                              <AlertCircle className="h-4 w-4 text-red-500" />
                            )}
                          </div>
                          <span className="text-xs text-muted-foreground">Mín: {producto.umbralMinimo}</span>
                        </div>
                        <div className="flex justify-end gap-2">
                          <Button variant="outline" size="sm" onClick={() => abrirMovimientoInventario(producto)}>
                            <BarChart3 className="mr-1 h-3 w-3" />
                            Movimiento
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => abrirEditarProducto(producto)}
                            className="text-amber-500 hover:text-amber-600 hover:bg-amber-50"
                          >
                            <Edit className="mr-1 h-3 w-3" />
                            Editar
                          </Button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="col-span-full rounded-lg border border-dashed p-8 text-center">
                      <h3 className="text-lg font-medium">No se encontraron productos</h3>
                      <p className="mt-1 text-sm text-gray-500">Intenta con otra búsqueda o agrega un nuevo producto</p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña de Movimientos de Inventario */}
        <TabsContent value="movimientos" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Movimientos de Inventario</CardTitle>
              <CardDescription>Historial de entradas y salidas de productos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Fecha</TableHead>
                      <TableHead>Producto</TableHead>
                      <TableHead>Tipo</TableHead>
                      <TableHead>Cantidad</TableHead>
                      <TableHead>Motivo</TableHead>
                      <TableHead>Usuario</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {movimientos.slice(0, 20).map((movimiento) => (
                      <TableRow key={movimiento.id}>
                        <TableCell>{format(parseISO(movimiento.fecha), "dd/MM/yyyy")}</TableCell>
                        <TableCell className="font-medium">{getNombreProducto(movimiento.productoId)}</TableCell>
                        <TableCell>
                          {movimiento.tipo === "entrada" ? (
                            <div className="flex items-center gap-1 text-green-600">
                              <ArrowUpCircle className="h-4 w-4" />
                              <span>Entrada</span>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1 text-red-600">
                              <ArrowDownCircle className="h-4 w-4" />
                              <span>Salida</span>
                            </div>
                          )}
                        </TableCell>
                        <TableCell>{movimiento.cantidad}</TableCell>
                        <TableCell>{movimiento.motivo}</TableCell>
                        <TableCell>{movimiento.usuario}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
              <div className="mt-4 text-center text-sm text-muted-foreground">
                Mostrando los últimos 20 movimientos de un total de {movimientos.length}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Modal para crear/editar producto */}
      <Dialog open={modalProducto} onOpenChange={setModalProducto}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>{productoActual ? "Editar Producto" : "Nuevo Producto"}</DialogTitle>
            <DialogDescription>
              {productoActual
                ? "Modifica los datos del producto seleccionado"
                : "Completa los campos para agregar un nuevo producto"}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="nombre">Nombre</Label>
                <Input id="nombre" defaultValue={productoActual?.nombre || ""} placeholder="Nombre del producto" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="categoria">Categoría</Label>
                <Select defaultValue={productoActual?.categoria || ""}>
                  <SelectTrigger id="categoria">
                    <SelectValue placeholder="Seleccionar categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    {categorias.map((categoria) => (
                      <SelectItem key={categoria} value={categoria}>
                        {categoria}
                      </SelectItem>
                    ))}
                    <SelectItem value="nueva">+ Nueva categoría</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="descripcion">Descripción</Label>
              <Textarea
                id="descripcion"
                defaultValue={productoActual?.descripcion || ""}
                placeholder="Descripción detallada del producto"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="precio">Precio</Label>
                <Input
                  id="precio"
                  type="number"
                  defaultValue={productoActual?.precio || 0}
                  placeholder="0.00"
                  min={0}
                  step={0.01}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="proveedor">Proveedor</Label>
                <Select defaultValue={productoActual?.proveedor || ""}>
                  <SelectTrigger id="proveedor">
                    <SelectValue placeholder="Seleccionar proveedor" />
                  </SelectTrigger>
                  <SelectContent>
                    {proveedores.map((proveedor) => (
                      <SelectItem key={proveedor.id} value={proveedor.nombre}>
                        {proveedor.nombre}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="existencias">Existencias</Label>
                <Input
                  id="existencias"
                  type="number"
                  defaultValue={productoActual?.existencias || 0}
                  placeholder="0"
                  min={0}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="umbralMinimo">Umbral Mínimo</Label>
                <Input
                  id="umbralMinimo"
                  type="number"
                  defaultValue={productoActual?.umbralMinimo || 5}
                  placeholder="5"
                  min={1}
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="imagen">URL de Imagen</Label>
              <Input
                id="imagen"
                defaultValue={productoActual?.imagen || "/placeholder.svg?height=100&width=100"}
                placeholder="URL de la imagen del producto"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalProducto(false)}>
              Cancelar
            </Button>
            <Button
              onClick={() => {
                // Aquí se recogerían los valores del formulario
                // Por simplicidad, usamos valores de ejemplo
                const nuevoProducto: Producto = {
                  id: productoActual?.id || 0,
                  nombre: "Nuevo Producto",
                  descripcion: "Descripción del nuevo producto",
                  categoria: "Productos para cabello",
                  precio: 100,
                  existencias: 10,
                  umbralMinimo: 5,
                  imagen: "/placeholder.svg?height=100&width=100",
                  proveedor: "Distribuidora de Belleza S.A.",
                  activo: true,
                }
                guardarProducto(nuevoProducto)
              }}
              className="bg-amber-500 hover:bg-amber-600"
            >
              {productoActual ? "Guardar Cambios" : "Agregar Producto"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para eliminar producto */}
      <Dialog open={modalEliminar} onOpenChange={setModalEliminar}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Eliminar Producto</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas eliminar este producto? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {productoActual && (
              <div className="rounded-lg border p-4">
                <div className="flex items-center gap-3">
                  <img
                    src={productoActual.imagen || "/placeholder.svg"}
                    alt={productoActual.nombre}
                    className="h-12 w-12 rounded-md object-cover"
                  />
                  <div>
                    <p className="font-medium">{productoActual.nombre}</p>
                    <p className="text-sm text-muted-foreground">
                      {productoActual.existencias} unidades en stock | ${productoActual.precio.toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalEliminar(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={eliminarProducto}>
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para registrar movimiento de inventario */}
      <Dialog open={modalMovimiento} onOpenChange={setModalMovimiento}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Registrar Movimiento de Inventario</DialogTitle>
            <DialogDescription>Registra una entrada o salida de producto en el inventario</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {productoActual && (
              <div className="mb-4 rounded-lg border p-4">
                <div className="flex items-center gap-3">
                  <img
                    src={productoActual.imagen || "/placeholder.svg"}
                    alt={productoActual.nombre}
                    className="h-12 w-12 rounded-md object-cover"
                  />
                  <div>
                    <p className="font-medium">{productoActual.nombre}</p>
                    <p className="text-sm text-muted-foreground">
                      Existencias actuales: <span className="font-medium">{productoActual.existencias}</span>
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="grid gap-4">
              <div className="grid gap-2">
                <Label htmlFor="tipoMovimiento">Tipo de Movimiento</Label>
                <Select defaultValue="entrada">
                  <SelectTrigger id="tipoMovimiento">
                    <SelectValue placeholder="Seleccionar tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="entrada">Entrada</SelectItem>
                    <SelectItem value="salida">Salida</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="cantidad">Cantidad</Label>
                <Input id="cantidad" type="number" placeholder="0" min={1} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="motivo">Motivo</Label>
                <Select defaultValue="compra">
                  <SelectTrigger id="motivo">
                    <SelectValue placeholder="Seleccionar motivo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="compra">Compra a proveedor</SelectItem>
                    <SelectItem value="venta">Venta a cliente</SelectItem>
                    <SelectItem value="uso">Uso interno</SelectItem>
                    <SelectItem value="ajuste">Ajuste de inventario</SelectItem>
                    <SelectItem value="devolucion">Devolución</SelectItem>
                    <SelectItem value="dañado">Producto dañado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="observaciones">Observaciones</Label>
                <Textarea id="observaciones" placeholder="Observaciones adicionales (opcional)" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalMovimiento(false)}>
              Cancelar
            </Button>
            <Button
              onClick={() => {
                // Aquí se recogerían los valores del formulario
                // Por simplicidad, usamos valores de ejemplo
                if (productoActual) {
                  const nuevoMovimiento = {
                    productoId: productoActual.id,
                    tipo: "entrada" as const,
                    cantidad: 5,
                    motivo: "Compra a proveedor",
                  }
                  registrarMovimiento(nuevoMovimiento)
                }
              }}
              className="bg-amber-500 hover:bg-amber-600"
            >
              Registrar Movimiento
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
