"use client"

import { useState } from "react"
import { PlusCircle, Search, Trash2, Edit } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"

// Tipo para los servicios
interface Servicio {
  id: number
  nombre: string
  duracion: number
  costo: number
}

// Datos de ejemplo
const serviciosIniciales: Servicio[] = [
  { id: 1, nombre: "Corte de cabello", duracion: 30, costo: 150 },
  { id: 2, nombre: "Afeitado tradicional", duracion: 25, costo: 120 },
  { id: 3, nombre: "Corte y barba", duracion: 45, costo: 250 },
  { id: 4, nombre: "Fade", duracion: 35, costo: 180 },
  { id: 5, nombre: "Lavado y peinado", duracion: 20, costo: 100 },
  { id: 6, nombre: "Tratamiento capilar", duracion: 40, costo: 300 },
]

export default function ServiciosPage() {
  // Estados
  const [servicios, setServicios] = useState<Servicio[]>(serviciosIniciales)
  const [busqueda, setBusqueda] = useState("")
  const [filtro, setFiltro] = useState<string>("todos")
  const [servicioActual, setServicioActual] = useState<Servicio | null>(null)
  const [modalAbierto, setModalAbierto] = useState(false)
  const [modalEliminar, setModalEliminar] = useState(false)

  // Formulario
  const [nombre, setNombre] = useState("")
  const [duracion, setDuracion] = useState("")
  const [costo, setCosto] = useState("")

  // Filtrar servicios
  const serviciosFiltrados = servicios.filter((servicio) => {
    const coincideBusqueda = servicio.nombre.toLowerCase().includes(busqueda.toLowerCase())

    if (filtro === "todos") return coincideBusqueda
    if (filtro === "corto") return coincideBusqueda && servicio.duracion <= 30
    if (filtro === "largo") return coincideBusqueda && servicio.duracion > 30

    return coincideBusqueda
  })

  // Abrir modal para crear nuevo servicio
  const abrirModalCrear = () => {
    setServicioActual(null)
    setNombre("")
    setDuracion("")
    setCosto("")
    setModalAbierto(true)
  }

  // Abrir modal para editar servicio
  const abrirModalEditar = (servicio: Servicio) => {
    setServicioActual(servicio)
    setNombre(servicio.nombre)
    setDuracion(servicio.duracion.toString())
    setCosto(servicio.costo.toString())
    setModalAbierto(true)
  }

  // Abrir modal para confirmar eliminación
  const abrirModalEliminar = (servicio: Servicio) => {
    setServicioActual(servicio)
    setModalEliminar(true)
  }

  // Guardar servicio (crear o actualizar)
  const guardarServicio = () => {
    if (!nombre || !duracion || !costo) return

    const nuevoServicio = {
      id: servicioActual ? servicioActual.id : Math.max(...servicios.map((s) => s.id), 0) + 1,
      nombre,
      duracion: Number.parseInt(duracion),
      costo: Number.parseInt(costo),
    }

    if (servicioActual) {
      // Actualizar servicio existente
      setServicios(servicios.map((s) => (s.id === servicioActual.id ? nuevoServicio : s)))
    } else {
      // Crear nuevo servicio
      setServicios([...servicios, nuevoServicio])
    }

    setModalAbierto(false)
  }

  // Eliminar servicio
  const eliminarServicio = () => {
    if (servicioActual) {
      setServicios(servicios.filter((s) => s.id !== servicioActual.id))
      setModalEliminar(false)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Servicios</h1>
          <p className="text-muted-foreground">Gestiona los servicios ofrecidos por la barbería</p>
        </div>
        <Button onClick={abrirModalCrear} className="bg-amber-500 hover:bg-amber-600">
          <PlusCircle className="mr-2 h-4 w-4" />
          Nuevo Servicio
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Listado de Servicios</CardTitle>
          <CardDescription>Visualiza, busca y filtra todos los servicios disponibles</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6 flex flex-col gap-4 sm:flex-row">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar por nombre..."
                className="pl-8"
                value={busqueda}
                onChange={(e) => setBusqueda(e.target.value)}
              />
            </div>
            <Select value={filtro} onValueChange={setFiltro}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Filtrar por duración" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos los servicios</SelectItem>
                <SelectItem value="corto">Duración &leq; 30 min</SelectItem>
                <SelectItem value="largo">Duración &gt; 30 min</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[80px]">ID</TableHead>
                  <TableHead>Nombre</TableHead>
                  <TableHead className="w-[150px]">Duración (min)</TableHead>
                  <TableHead className="w-[150px]">Costo ($)</TableHead>
                  <TableHead className="w-[100px] text-right">Acciones</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {serviciosFiltrados.length > 0 ? (
                  serviciosFiltrados.map((servicio) => (
                    <TableRow key={servicio.id}>
                      <TableCell className="font-medium">{servicio.id}</TableCell>
                      <TableCell>{servicio.nombre}</TableCell>
                      <TableCell>
                        {servicio.duracion}
                        {servicio.duracion <= 30 ? (
                          <Badge variant="outline" className="ml-2 bg-green-50 text-green-700">
                            Corto
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="ml-2 bg-blue-50 text-blue-700">
                            Largo
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>${servicio.costo}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => abrirModalEditar(servicio)}
                          className="text-amber-500 hover:text-amber-600 hover:bg-amber-50"
                        >
                          <Edit className="h-4 w-4" />
                          <span className="sr-only">Editar</span>
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => abrirModalEliminar(servicio)}
                          className="text-red-500 hover:text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Eliminar</span>
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={5} className="h-24 text-center">
                      No se encontraron servicios
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Modal para crear/editar servicio */}
      <Dialog open={modalAbierto} onOpenChange={setModalAbierto}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{servicioActual ? "Editar Servicio" : "Nuevo Servicio"}</DialogTitle>
            <DialogDescription>
              {servicioActual
                ? "Modifica los detalles del servicio seleccionado"
                : "Completa los campos para crear un nuevo servicio"}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="nombre">Nombre del servicio</Label>
              <Input
                id="nombre"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                placeholder="Ej: Corte de cabello"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="duracion">Duración (minutos)</Label>
              <Input
                id="duracion"
                type="number"
                value={duracion}
                onChange={(e) => setDuracion(e.target.value)}
                placeholder="Ej: 30"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="costo">Costo ($)</Label>
              <Input
                id="costo"
                type="number"
                value={costo}
                onChange={(e) => setCosto(e.target.value)}
                placeholder="Ej: 150"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalAbierto(false)}>
              Cancelar
            </Button>
            <Button onClick={guardarServicio} className="bg-amber-500 hover:bg-amber-600">
              Guardar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para confirmar eliminación */}
      <Dialog open={modalEliminar} onOpenChange={setModalEliminar}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Eliminar Servicio</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas eliminar este servicio? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {servicioActual && (
              <div className="rounded-lg border p-4">
                <p className="font-medium">{servicioActual.nombre}</p>
                <p className="text-sm text-muted-foreground">
                  Duración: {servicioActual.duracion} min | Costo: ${servicioActual.costo}
                </p>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalEliminar(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={eliminarServicio}>
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
