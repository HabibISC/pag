import { CalendarDays, Clock, DollarSign, Scissors, Users } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Panel de Control</h1>
        <p className="text-muted-foreground">Bienvenido al sistema de gestión de Barbería "El Filo"</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Citas Hoy</CardTitle>
            <CalendarDays className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">4 pendientes, 8 completadas</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ingresos del Día</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$1,850</div>
            <p className="text-xs text-muted-foreground">+15% respecto a ayer</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Clientes Nuevos</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">+2 respecto a ayer</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Próximas Citas</CardTitle>
            <CardDescription>Citas programadas para hoy</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between rounded-lg border p-3">
                <div className="flex items-center gap-3">
                  <div className="rounded-full bg-amber-100 p-2">
                    <Clock className="h-4 w-4 text-amber-700" />
                  </div>
                  <div>
                    <p className="font-medium">Carlos Mendoza</p>
                    <p className="text-sm text-gray-500">Corte y barba</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium">15:30</p>
                  <p className="text-sm text-gray-500">30 min</p>
                </div>
              </div>
              <div className="flex items-center justify-between rounded-lg border p-3">
                <div className="flex items-center gap-3">
                  <div className="rounded-full bg-amber-100 p-2">
                    <Clock className="h-4 w-4 text-amber-700" />
                  </div>
                  <div>
                    <p className="font-medium">Miguel Ángel</p>
                    <p className="text-sm text-gray-500">Corte fade</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium">16:15</p>
                  <p className="text-sm text-gray-500">20 min</p>
                </div>
              </div>
              <div className="flex items-center justify-between rounded-lg border p-3">
                <div className="flex items-center gap-3">
                  <div className="rounded-full bg-amber-100 p-2">
                    <Clock className="h-4 w-4 text-amber-700" />
                  </div>
                  <div>
                    <p className="font-medium">Roberto Sánchez</p>
                    <p className="text-sm text-gray-500">Corte y afeitado</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium">17:00</p>
                  <p className="text-sm text-gray-500">45 min</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Servicios Populares</CardTitle>
            <CardDescription>Los servicios más solicitados este mes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="rounded-full bg-green-100 p-2">
                    <Scissors className="h-4 w-4 text-green-700" />
                  </div>
                  <div>
                    <p className="font-medium">Corte Fade</p>
                    <div className="mt-1 h-2 w-full rounded-full bg-gray-100">
                      <div className="h-2 w-[85%] rounded-full bg-green-500"></div>
                    </div>
                  </div>
                </div>
                <p className="font-medium">85%</p>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="rounded-full bg-green-100 p-2">
                    <Scissors className="h-4 w-4 text-green-700" />
                  </div>
                  <div>
                    <p className="font-medium">Barba Completa</p>
                    <div className="mt-1 h-2 w-full rounded-full bg-gray-100">
                      <div className="h-2 w-[65%] rounded-full bg-green-500"></div>
                    </div>
                  </div>
                </div>
                <p className="font-medium">65%</p>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="rounded-full bg-green-100 p-2">
                    <Scissors className="h-4 w-4 text-green-700" />
                  </div>
                  <div>
                    <p className="font-medium">Corte y Barba</p>
                    <div className="mt-1 h-2 w-full rounded-full bg-gray-100">
                      <div className="h-2 w-[50%] rounded-full bg-green-500"></div>
                    </div>
                  </div>
                </div>
                <p className="font-medium">50%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
