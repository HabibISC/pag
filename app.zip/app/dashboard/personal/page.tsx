"use client"

import { useState } from "react"
import { format, parseISO, startOfMonth, endOfMonth, eachDayOfInterval } from "date-fns"
import { BarChart, Clock, Edit, MoreVertical, Plus, Star, Trash2, Users } from "lucide-react"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Tipos
interface Empleado {
  id: number
  nombre: string
  apellido: string
  rol: string
  telefono: string
  email: string
  sueldo: number
  fechaContratacion: string
  color: string
  activo: boolean
}

interface Turno {
  id: number
  empleadoId: number
  dia: string
  horaInicio: string
  horaFin: string
  recurrente: boolean
}

interface Rendimiento {
  id: number
  empleadoId: number
  fecha: string
  serviciosCompletados: number
  tiempoPromedio: number
  valoracionPromedio: number
}

// Datos de ejemplo
const empleadosIniciales: Empleado[] = [
  {
    id: 1,
    nombre: "Juan",
    apellido: "Pérez",
    rol: "Barbero",
    telefono: "555-1234",
    email: "juan@elfilo.com",
    sueldo: 15000,
    fechaContratacion: "2023-01-15",
    color: "#f59e0b",
    activo: true,
  },
  {
    id: 2,
    nombre: "Miguel",
    apellido: "Rodríguez",
    rol: "Barbero",
    telefono: "555-5678",
    email: "miguel@elfilo.com",
    sueldo: 14000,
    fechaContratacion: "2023-03-20",
    color: "#3b82f6",
    activo: true,
  },
  {
    id: 3,
    nombre: "Carlos",
    apellido: "Sánchez",
    rol: "Barbero",
    telefono: "555-9012",
    email: "carlos@elfilo.com",
    sueldo: 14500,
    fechaContratacion: "2023-02-10",
    color: "#10b981",
    activo: true,
  },
  {
    id: 4,
    nombre: "Ana",
    apellido: "Martínez",
    rol: "Recepcionista",
    telefono: "555-3456",
    email: "ana@elfilo.com",
    sueldo: 12000,
    fechaContratacion: "2023-04-05",
    color: "#ec4899",
    activo: true,
  },
  {
    id: 5,
    nombre: "Luis",
    apellido: "Gómez",
    rol: "Limpieza",
    telefono: "555-7890",
    email: "luis@elfilo.com",
    sueldo: 10000,
    fechaContratacion: "2023-05-12",
    color: "#8b5cf6",
    activo: false,
  },
]

const turnosIniciales: Turno[] = [
  { id: 1, empleadoId: 1, dia: "Lunes", horaInicio: "09:00", horaFin: "17:00", recurrente: true },
  { id: 2, empleadoId: 1, dia: "Martes", horaInicio: "09:00", horaFin: "17:00", recurrente: true },
  { id: 3, empleadoId: 1, dia: "Miércoles", horaInicio: "09:00", horaFin: "17:00", recurrente: true },
  { id: 4, empleadoId: 1, dia: "Jueves", horaInicio: "12:00", horaFin: "20:00", recurrente: true },
  { id: 5, empleadoId: 1, dia: "Viernes", horaInicio: "12:00", horaFin: "20:00", recurrente: true },
  { id: 6, empleadoId: 2, dia: "Lunes", horaInicio: "12:00", horaFin: "20:00", recurrente: true },
  { id: 7, empleadoId: 2, dia: "Martes", horaInicio: "12:00", horaFin: "20:00", recurrente: true },
  { id: 8, empleadoId: 2, dia: "Miércoles", horaInicio: "12:00", horaFin: "20:00", recurrente: true },
  { id: 9, empleadoId: 2, dia: "Sábado", horaInicio: "09:00", horaFin: "17:00", recurrente: true },
  { id: 10, empleadoId: 2, dia: "Domingo", horaInicio: "09:00", horaFin: "15:00", recurrente: true },
  { id: 11, empleadoId: 3, dia: "Miércoles", horaInicio: "09:00", horaFin: "17:00", recurrente: true },
  { id: 12, empleadoId: 3, dia: "Jueves", horaInicio: "09:00", horaFin: "17:00", recurrente: true },
  { id: 13, empleadoId: 3, dia: "Viernes", horaInicio: "09:00", horaFin: "17:00", recurrente: true },
  { id: 14, empleadoId: 3, dia: "Sábado", horaInicio: "12:00", horaFin: "20:00", recurrente: true },
  { id: 15, empleadoId: 3, dia: "Domingo", horaInicio: "09:00", horaFin: "15:00", recurrente: true },
  { id: 16, empleadoId: 4, dia: "Lunes", horaInicio: "09:00", horaFin: "17:00", recurrente: true },
  { id: 17, empleadoId: 4, dia: "Martes", horaInicio: "09:00", horaFin: "17:00", recurrente: true },
  { id: 18, empleadoId: 4, dia: "Miércoles", horaInicio: "09:00", horaFin: "17:00", recurrente: true },
  { id: 19, empleadoId: 4, dia: "Jueves", horaInicio: "09:00", horaFin: "17:00", recurrente: true },
  { id: 20, empleadoId: 4, dia: "Viernes", horaInicio: "09:00", horaFin: "17:00", recurrente: true },
]

// Generar datos de rendimiento para los últimos 30 días
const rendimientoInicial: Rendimiento[] = []
const hoy = new Date()
const fechasRendimiento = eachDayOfInterval({
  start: startOfMonth(hoy),
  end: endOfMonth(hoy),
})

// Generar datos aleatorios para cada barbero
empleadosIniciales
  .filter((e) => e.rol === "Barbero" && e.activo)
  .forEach((empleado) => {
    fechasRendimiento.forEach((fecha, index) => {
      // Solo incluir días laborables (lunes a domingo)
      const diaSemana = fecha.getDay()
      if (diaSemana >= 1 && diaSemana <= 7) {
        // Generar datos con cierta variabilidad pero con tendencia
        const base = 8 + Math.floor(Math.random() * 5) // Entre 8 y 12 servicios base
        const tendencia = Math.sin((index / fechasRendimiento.length) * Math.PI) * 3 // Variación sinusoidal
        const servicios = Math.max(1, Math.round(base + tendencia))

        rendimientoInicial.push({
          id: rendimientoInicial.length + 1,
          empleadoId: empleado.id,
          fecha: format(fecha, "yyyy-MM-dd"),
          serviciosCompletados: servicios,
          tiempoPromedio: 25 + Math.floor(Math.random() * 15), // Entre 25 y 40 minutos
          valoracionPromedio: 3.5 + Math.random() * 1.5, // Entre 3.5 y 5
        })
      }
    })
  })

export default function PersonalPage() {
  // Estados
  const [empleados, setEmpleados] = useState<Empleado[]>(empleadosIniciales)
  const [turnos, setTurnos] = useState<Turno[]>(turnosIniciales)
  const [rendimientos] = useState<Rendimiento[]>(rendimientoInicial)
  const [empleadoActual, setEmpleadoActual] = useState<Empleado | null>(null)
  const [turnoActual, setTurnoActual] = useState<Turno | null>(null)
  const [modalEmpleado, setModalEmpleado] = useState(false)
  const [modalTurno, setModalTurno] = useState(false)
  const [modalEliminar, setModalEliminar] = useState(false)
  const [modalEliminarTurno, setModalEliminarTurno] = useState(false)
  const [empleadoSeleccionado, setEmpleadoSeleccionado] = useState<number | null>(null)
  const [mesSeleccionado, setMesSeleccionado] = useState<string>(format(new Date(), "yyyy-MM"))

  // Toast para notificaciones
  const { toast } = useToast()

  // Función para abrir el modal de nuevo empleado
  const abrirNuevoEmpleado = () => {
    setEmpleadoActual(null)
    setModalEmpleado(true)
  }

  // Función para abrir el modal de edición de empleado
  const abrirEditarEmpleado = (empleado: Empleado) => {
    setEmpleadoActual({ ...empleado })
    setModalEmpleado(true)
  }

  // Función para abrir el modal de eliminación de empleado
  const abrirEliminarEmpleado = (empleado: Empleado) => {
    setEmpleadoActual(empleado)
    setModalEliminar(true)
  }

  // Función para guardar empleado (crear o actualizar)
  const guardarEmpleado = (empleado: Empleado) => {
    if (empleadoActual) {
      // Actualizar empleado existente
      setEmpleados(empleados.map((e) => (e.id === empleado.id ? empleado : e)))
      toast({
        title: "Empleado actualizado",
        description: `Se ha actualizado la información de ${empleado.nombre} ${empleado.apellido}`,
      })
    } else {
      // Crear nuevo empleado
      const nuevoEmpleado = {
        ...empleado,
        id: Math.max(...empleados.map((e) => e.id), 0) + 1,
      }
      setEmpleados([...empleados, nuevoEmpleado])
      toast({
        title: "Empleado agregado",
        description: `Se ha agregado a ${empleado.nombre} ${empleado.apellido} al equipo`,
      })
    }
    setModalEmpleado(false)
  }

  // Función para eliminar empleado
  const eliminarEmpleado = () => {
    if (empleadoActual) {
      // Marcar como inactivo en lugar de eliminar completamente
      setEmpleados(empleados.map((e) => (e.id === empleadoActual.id ? { ...e, activo: false } : e)))
      toast({
        title: "Empleado eliminado",
        description: `Se ha eliminado a ${empleadoActual.nombre} ${empleadoActual.apellido} del equipo`,
        variant: "destructive",
      })
      setModalEliminar(false)
    }
  }

  // Función para abrir el modal de nuevo turno
  const abrirNuevoTurno = (empleadoId: number) => {
    setEmpleadoSeleccionado(empleadoId)
    setTurnoActual(null)
    setModalTurno(true)
  }

  // Función para abrir el modal de edición de turno
  const abrirEditarTurno = (turno: Turno) => {
    setTurnoActual({ ...turno })
    setEmpleadoSeleccionado(turno.empleadoId)
    setModalTurno(true)
  }

  // Función para abrir el modal de eliminación de turno
  const abrirEliminarTurno = (turno: Turno) => {
    setTurnoActual(turno)
    setModalEliminarTurno(true)
  }

  // Función para guardar turno (crear o actualizar)
  const guardarTurno = (turno: Turno) => {
    if (turnoActual) {
      // Actualizar turno existente
      setTurnos(turnos.map((t) => (t.id === turno.id ? turno : t)))
      toast({
        title: "Turno actualizado",
        description: `Se ha actualizado el turno de ${
          empleados.find((e) => e.id === turno.empleadoId)?.nombre || ""
        } para el día ${turno.dia}`,
      })
    } else {
      // Crear nuevo turno
      const nuevoTurno = {
        ...turno,
        id: Math.max(...turnos.map((t) => t.id), 0) + 1,
      }
      setTurnos([...turnos, nuevoTurno])
      toast({
        title: "Turno agregado",
        description: `Se ha agregado un nuevo turno para ${
          empleados.find((e) => e.id === turno.empleadoId)?.nombre || ""
        } el día ${turno.dia}`,
      })
    }
    setModalTurno(false)
  }

  // Función para eliminar turno
  const eliminarTurno = () => {
    if (turnoActual) {
      setTurnos(turnos.filter((t) => t.id !== turnoActual.id))
      toast({
        title: "Turno eliminado",
        description: `Se ha eliminado el turno de ${
          empleados.find((e) => e.id === turnoActual.empleadoId)?.nombre || ""
        } para el día ${turnoActual.dia}`,
        variant: "destructive",
      })
      setModalEliminarTurno(false)
    }
  }

  // Obtener turnos por empleado
  const getTurnosPorEmpleado = (empleadoId: number) => {
    return turnos.filter((turno) => turno.empleadoId === empleadoId)
  }

  // Obtener rendimiento por empleado y mes
  const getRendimientoPorEmpleado = (empleadoId: number) => {
    const [year, month] = mesSeleccionado.split("-")
    return rendimientos.filter((r) => r.empleadoId === empleadoId && r.fecha.startsWith(`${year}-${month}`))
  }

  // Calcular promedios de rendimiento para un empleado
  const calcularPromedios = (empleadoId: number) => {
    const rendimientoEmpleado = getRendimientoPorEmpleado(empleadoId)
    if (rendimientoEmpleado.length === 0) return { servicios: 0, tiempo: 0, valoracion: 0 }

    const totalServicios = rendimientoEmpleado.reduce((sum, r) => sum + r.serviciosCompletados, 0)
    const tiempoPromedio =
      rendimientoEmpleado.reduce((sum, r) => sum + r.tiempoPromedio, 0) / rendimientoEmpleado.length
    const valoracionPromedio =
      rendimientoEmpleado.reduce((sum, r) => sum + r.valoracionPromedio, 0) / rendimientoEmpleado.length

    return {
      servicios: totalServicios,
      tiempo: Math.round(tiempoPromedio),
      valoracion: Math.round(valoracionPromedio * 10) / 10,
    }
  }

  // Obtener solo empleados activos
  const empleadosActivos = empleados.filter((e) => e.activo)

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Gestión de Personal</h1>
        <p className="text-muted-foreground">Administra la información del equipo, turnos y rendimiento</p>
      </div>

      <Tabs defaultValue="empleados" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="empleados">
            <Users className="mr-2 h-4 w-4" />
            Empleados
          </TabsTrigger>
          <TabsTrigger value="turnos">
            <Clock className="mr-2 h-4 w-4" />
            Turnos
          </TabsTrigger>
          <TabsTrigger value="rendimiento">
            <BarChart className="mr-2 h-4 w-4" />
            Rendimiento
          </TabsTrigger>
        </TabsList>

        {/* Pestaña de Empleados */}
        <TabsContent value="empleados" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Administración de Empleados</CardTitle>
                <CardDescription>Gestiona la información del personal de la barbería</CardDescription>
              </div>
              <Button onClick={abrirNuevoEmpleado} className="bg-amber-500 hover:bg-amber-600">
                <Plus className="mr-2 h-4 w-4" />
                Agregar Empleado
              </Button>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nombre</TableHead>
                      <TableHead>Rol</TableHead>
                      <TableHead>Teléfono</TableHead>
                      <TableHead>Sueldo</TableHead>
                      <TableHead>Estado</TableHead>
                      <TableHead className="text-right">Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {empleados.map((empleado) => (
                      <TableRow key={empleado.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <div className="h-6 w-6 rounded-full" style={{ backgroundColor: empleado.color }}></div>
                            <span className="font-medium">
                              {empleado.nombre} {empleado.apellido}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>{empleado.rol}</TableCell>
                        <TableCell>{empleado.telefono}</TableCell>
                        <TableCell>${empleado.sueldo.toLocaleString()}</TableCell>
                        <TableCell>
                          {empleado.activo ? (
                            <Badge className="bg-green-100 text-green-800">Activo</Badge>
                          ) : (
                            <Badge variant="outline" className="bg-red-100 text-red-800">
                              Inactivo
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => abrirEditarEmpleado(empleado)}>
                                <Edit className="mr-2 h-4 w-4" />
                                Editar
                              </DropdownMenuItem>
                              {empleado.activo && (
                                <>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem
                                    className="text-red-600"
                                    onClick={() => abrirEliminarEmpleado(empleado)}
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    Eliminar
                                  </DropdownMenuItem>
                                </>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña de Turnos */}
        <TabsContent value="turnos" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Gestión de Turnos</CardTitle>
              <CardDescription>Administra los horarios y turnos del personal</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {empleadosActivos.map((empleado) => {
                  const turnosEmpleado = getTurnosPorEmpleado(empleado.id)
                  return (
                    <div key={empleado.id} className="rounded-lg border p-4">
                      <div className="mb-4 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="h-6 w-6 rounded-full" style={{ backgroundColor: empleado.color }}></div>
                          <h3 className="text-lg font-medium">
                            {empleado.nombre} {empleado.apellido}
                          </h3>
                          <Badge>{empleado.rol}</Badge>
                        </div>
                        <Button
                          size="sm"
                          onClick={() => abrirNuevoTurno(empleado.id)}
                          className="bg-amber-500 hover:bg-amber-600"
                        >
                          <Plus className="mr-2 h-4 w-4" />
                          Asignar Turno
                        </Button>
                      </div>

                      {turnosEmpleado.length > 0 ? (
                        <div className="rounded-md border">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Día</TableHead>
                                <TableHead>Hora Inicio</TableHead>
                                <TableHead>Hora Fin</TableHead>
                                <TableHead>Recurrente</TableHead>
                                <TableHead className="text-right">Acciones</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {turnosEmpleado.map((turno) => (
                                <TableRow key={turno.id}>
                                  <TableCell className="font-medium">{turno.dia}</TableCell>
                                  <TableCell>{turno.horaInicio}</TableCell>
                                  <TableCell>{turno.horaFin}</TableCell>
                                  <TableCell>
                                    {turno.recurrente ? (
                                      <Badge className="bg-blue-100 text-blue-800">Semanal</Badge>
                                    ) : (
                                      <Badge variant="outline">Único</Badge>
                                    )}
                                  </TableCell>
                                  <TableCell className="text-right">
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => abrirEditarTurno(turno)}
                                      className="text-amber-500 hover:text-amber-600 hover:bg-amber-50"
                                    >
                                      <Edit className="h-4 w-4" />
                                      <span className="sr-only">Editar</span>
                                    </Button>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      onClick={() => abrirEliminarTurno(turno)}
                                      className="text-red-500 hover:text-red-600 hover:bg-red-50"
                                    >
                                      <Trash2 className="h-4 w-4" />
                                      <span className="sr-only">Eliminar</span>
                                    </Button>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </div>
                      ) : (
                        <div className="rounded-lg border border-dashed p-4 text-center text-muted-foreground">
                          No hay turnos asignados para este empleado
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña de Rendimiento */}
        <TabsContent value="rendimiento" className="mt-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Histórico de Rendimiento</CardTitle>
                <CardDescription>Visualiza el rendimiento del personal a lo largo del tiempo</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Label htmlFor="mes">Mes:</Label>
                <Input
                  id="mes"
                  type="month"
                  value={mesSeleccionado}
                  onChange={(e) => setMesSeleccionado(e.target.value)}
                  className="w-40"
                />
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {empleadosActivos
                  .filter((e) => e.rol === "Barbero")
                  .map((empleado) => {
                    const rendimientoEmpleado = getRendimientoPorEmpleado(empleado.id)
                    const promedios = calcularPromedios(empleado.id)
                    return (
                      <div key={empleado.id} className="rounded-lg border p-4">
                        <div className="mb-4 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="h-6 w-6 rounded-full" style={{ backgroundColor: empleado.color }}></div>
                            <h3 className="text-lg font-medium">
                              {empleado.nombre} {empleado.apellido}
                            </h3>
                          </div>
                        </div>

                        {rendimientoEmpleado.length > 0 ? (
                          <div className="space-y-4">
                            <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                              <div className="rounded-lg border p-4 text-center">
                                <div className="text-3xl font-bold text-amber-500">{promedios.servicios}</div>
                                <div className="text-sm text-muted-foreground">Servicios Completados</div>
                              </div>
                              <div className="rounded-lg border p-4 text-center">
                                <div className="text-3xl font-bold text-amber-500">{promedios.tiempo} min</div>
                                <div className="text-sm text-muted-foreground">Tiempo Promedio</div>
                              </div>
                              <div className="rounded-lg border p-4 text-center">
                                <div className="flex items-center justify-center">
                                  <div className="text-3xl font-bold text-amber-500 mr-2">{promedios.valoracion}</div>
                                  <Star className="h-5 w-5 fill-amber-500 text-amber-500" />
                                </div>
                                <div className="text-sm text-muted-foreground">Valoración Promedio</div>
                              </div>
                            </div>

                            <div className="rounded-lg border p-4">
                              <h4 className="mb-4 font-medium">Servicios por día</h4>
                              <div className="h-64">
                                <div className="flex h-full items-end gap-1">
                                  {rendimientoEmpleado.map((r) => (
                                    <div key={r.id} className="group relative flex flex-1 flex-col items-center">
                                      <div
                                        className="w-full bg-amber-500 rounded-t"
                                        style={{
                                          height: `${(r.serviciosCompletados / 15) * 100}%`,
                                        }}
                                      ></div>
                                      <div className="mt-1 text-xs">{format(parseISO(r.fecha), "dd")}</div>
                                      <div className="absolute bottom-full mb-1 hidden rounded bg-black px-2 py-1 text-xs text-white group-hover:block">
                                        {r.serviciosCompletados} servicios el {format(parseISO(r.fecha), "dd/MM")}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>

                            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                              <div className="rounded-lg border p-4">
                                <h4 className="mb-4 font-medium">Tiempo promedio por servicio</h4>
                                <div className="h-48">
                                  <div className="flex h-full items-end">
                                    <div className="relative h-full w-full">
                                      <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                                        <path
                                          d={`M0,100 ${rendimientoEmpleado
                                            .map(
                                              (r, i) =>
                                                `L${
                                                  (i / (rendimientoEmpleado.length - 1)) * 100
                                                },${100 - (r.tiempoPromedio / 60) * 100}`,
                                            )
                                            .join(" ")}`}
                                          stroke="#f59e0b"
                                          strokeWidth="2"
                                          fill="none"
                                        />
                                      </svg>
                                    </div>
                                  </div>
                                </div>
                              </div>

                              <div className="rounded-lg border p-4">
                                <h4 className="mb-4 font-medium">Valoraciones recibidas</h4>
                                <div className="h-48">
                                  <div className="flex h-full items-end">
                                    <div className="relative h-full w-full">
                                      <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                                        <path
                                          d={`M0,${100 - (rendimientoEmpleado[0]?.valoracionPromedio / 5) * 100} ${rendimientoEmpleado
                                            .map(
                                              (r, i) =>
                                                `L${
                                                  (i / (rendimientoEmpleado.length - 1)) * 100
                                                },${100 - (r.valoracionPromedio / 5) * 100}`,
                                            )
                                            .join(" ")}`}
                                          stroke="#f59e0b"
                                          strokeWidth="2"
                                          fill="none"
                                        />
                                      </svg>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="rounded-lg border border-dashed p-4 text-center text-muted-foreground">
                            No hay datos de rendimiento para este empleado en el mes seleccionado
                          </div>
                        )}
                      </div>
                    )
                  })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Modal para crear/editar empleado */}
      <Dialog open={modalEmpleado} onOpenChange={setModalEmpleado}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{empleadoActual ? "Editar Empleado" : "Nuevo Empleado"}</DialogTitle>
            <DialogDescription>
              {empleadoActual
                ? "Modifica los datos del empleado seleccionado"
                : "Completa los campos para agregar un nuevo empleado"}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="nombre">Nombre</Label>
                <Input id="nombre" defaultValue={empleadoActual?.nombre || ""} placeholder="Nombre" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="apellido">Apellido</Label>
                <Input id="apellido" defaultValue={empleadoActual?.apellido || ""} placeholder="Apellido" />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="rol">Rol</Label>
              <Select defaultValue={empleadoActual?.rol || "Barbero"}>
                <SelectTrigger id="rol">
                  <SelectValue placeholder="Seleccionar rol" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Barbero">Barbero</SelectItem>
                  <SelectItem value="Recepcionista">Recepcionista</SelectItem>
                  <SelectItem value="Limpieza">Limpieza</SelectItem>
                  <SelectItem value="Administrador">Administrador</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="telefono">Teléfono</Label>
                <Input id="telefono" defaultValue={empleadoActual?.telefono || ""} placeholder="555-1234" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  defaultValue={empleadoActual?.email || ""}
                  placeholder="ejemplo@elfilo.com"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="sueldo">Sueldo</Label>
                <Input id="sueldo" type="number" defaultValue={empleadoActual?.sueldo || 10000} placeholder="10000" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="fechaContratacion">Fecha de Contratación</Label>
                <Input
                  id="fechaContratacion"
                  type="date"
                  defaultValue={empleadoActual?.fechaContratacion || format(new Date(), "yyyy-MM-dd")}
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="color">Color (para identificación)</Label>
              <Input
                id="color"
                type="color"
                defaultValue={empleadoActual?.color || "#f59e0b"}
                className="h-10 w-full"
              />
            </div>
            {empleadoActual && (
              <div className="grid gap-2">
                <Label htmlFor="activo">Estado</Label>
                <Select defaultValue={empleadoActual.activo ? "activo" : "inactivo"}>
                  <SelectTrigger id="activo">
                    <SelectValue placeholder="Seleccionar estado" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="activo">Activo</SelectItem>
                    <SelectItem value="inactivo">Inactivo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalEmpleado(false)}>
              Cancelar
            </Button>
            <Button
              onClick={() => {
                // Aquí se recogerían los valores del formulario
                // Por simplicidad, usamos valores de ejemplo
                const nuevoEmpleado: Empleado = {
                  id: empleadoActual?.id || 0,
                  nombre: "Nuevo",
                  apellido: "Empleado",
                  rol: "Barbero",
                  telefono: "555-0000",
                  email: "nuevo@elfilo.com",
                  sueldo: 12000,
                  fechaContratacion: format(new Date(), "yyyy-MM-dd"),
                  color: "#f59e0b",
                  activo: true,
                }
                guardarEmpleado(nuevoEmpleado)
              }}
              className="bg-amber-500 hover:bg-amber-600"
            >
              {empleadoActual ? "Guardar Cambios" : "Agregar Empleado"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para eliminar empleado */}
      <Dialog open={modalEliminar} onOpenChange={setModalEliminar}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Eliminar Empleado</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas eliminar a este empleado? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {empleadoActual && (
              <div className="rounded-lg border p-4">
                <div className="flex items-center gap-2">
                  <div className="h-6 w-6 rounded-full" style={{ backgroundColor: empleadoActual.color }}></div>
                  <span className="font-medium">
                    {empleadoActual.nombre} {empleadoActual.apellido}
                  </span>
                </div>
                <div className="mt-2 text-sm text-muted-foreground">
                  {empleadoActual.rol} | {empleadoActual.email} | {empleadoActual.telefono}
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalEliminar(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={eliminarEmpleado}>
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para crear/editar turno */}
      <Dialog open={modalTurno} onOpenChange={setModalTurno}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{turnoActual ? "Editar Turno" : "Nuevo Turno"}</DialogTitle>
            <DialogDescription>
              {turnoActual
                ? "Modifica los detalles del turno seleccionado"
                : "Completa los campos para asignar un nuevo turno"}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            {empleadoSeleccionado && (
              <div className="rounded-lg border p-2">
                <div className="flex items-center gap-2">
                  <div
                    className="h-4 w-4 rounded-full"
                    style={{
                      backgroundColor: empleados.find((e) => e.id === empleadoSeleccionado)?.color || "#000",
                    }}
                  ></div>
                  <span className="text-sm font-medium">
                    {empleados.find((e) => e.id === empleadoSeleccionado)?.nombre}{" "}
                    {empleados.find((e) => e.id === empleadoSeleccionado)?.apellido}
                  </span>
                </div>
              </div>
            )}
            <div className="grid gap-2">
              <Label htmlFor="dia">Día</Label>
              <Select defaultValue={turnoActual?.dia || "Lunes"}>
                <SelectTrigger id="dia">
                  <SelectValue placeholder="Seleccionar día" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Lunes">Lunes</SelectItem>
                  <SelectItem value="Martes">Martes</SelectItem>
                  <SelectItem value="Miércoles">Miércoles</SelectItem>
                  <SelectItem value="Jueves">Jueves</SelectItem>
                  <SelectItem value="Viernes">Viernes</SelectItem>
                  <SelectItem value="Sábado">Sábado</SelectItem>
                  <SelectItem value="Domingo">Domingo</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="horaInicio">Hora de Inicio</Label>
                <Input id="horaInicio" type="time" defaultValue={turnoActual?.horaInicio || "09:00"} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="horaFin">Hora de Fin</Label>
                <Input id="horaFin" type="time" defaultValue={turnoActual?.horaFin || "17:00"} />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="recurrente">Tipo de Turno</Label>
              <Select defaultValue={turnoActual?.recurrente ? "recurrente" : "unico"}>
                <SelectTrigger id="recurrente">
                  <SelectValue placeholder="Seleccionar tipo" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recurrente">Recurrente (Semanal)</SelectItem>
                  <SelectItem value="unico">Único</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalTurno(false)}>
              Cancelar
            </Button>
            <Button
              onClick={() => {
                // Aquí se recogerían los valores del formulario
                // Por simplicidad, usamos valores de ejemplo
                if (empleadoSeleccionado) {
                  const nuevoTurno: Turno = {
                    id: turnoActual?.id || 0,
                    empleadoId: empleadoSeleccionado,
                    dia: "Lunes",
                    horaInicio: "09:00",
                    horaFin: "17:00",
                    recurrente: true,
                  }
                  guardarTurno(nuevoTurno)
                }
              }}
              className="bg-amber-500 hover:bg-amber-600"
            >
              {turnoActual ? "Guardar Cambios" : "Asignar Turno"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal para eliminar turno */}
      <Dialog open={modalEliminarTurno} onOpenChange={setModalEliminarTurno}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Eliminar Turno</DialogTitle>
            <DialogDescription>
              ¿Estás seguro de que deseas eliminar este turno? Esta acción no se puede deshacer.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            {turnoActual && (
              <div className="rounded-lg border p-4">
                <div className="font-medium">
                  {empleados.find((e) => e.id === turnoActual.empleadoId)?.nombre}{" "}
                  {empleados.find((e) => e.id === turnoActual.empleadoId)?.apellido}
                </div>
                <div className="mt-2 text-sm text-muted-foreground">
                  {turnoActual.dia} de {turnoActual.horaInicio} a {turnoActual.horaFin}
                </div>
                <div className="mt-1 text-xs text-muted-foreground">
                  {turnoActual.recurrente ? "Turno recurrente semanal" : "Turno único"}
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setModalEliminarTurno(false)}>
              Cancelar
            </Button>
            <Button variant="destructive" onClick={eliminarTurno}>
              Eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
