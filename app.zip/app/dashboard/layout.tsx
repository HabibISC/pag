import type React from "react"
import Link from "next/link"
import { BellRing, Calendar, ChevronDown, ClipboardList, Home, LogOut, Package, Settings, Users } from "lucide-react"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-10 flex h-16 items-center justify-between border-b bg-white px-4 shadow-sm">
        <div className="flex items-center gap-4">
          <Link href="/dashboard" className="flex items-center gap-2">
            <div className="relative h-10 w-10 overflow-hidden rounded-full bg-amber-500">
              <img src="/images/logo-el-filo.png" alt="Logo de El Filo" className="object-cover" />
            </div>
            <span className="text-lg font-bold">El Filo</span>
          </Link>
        </div>

        <div className="flex items-center gap-4">
          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="relative rounded-full p-2 hover:bg-gray-100">
                <BellRing className="h-5 w-5" />
                <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-red-500"></span>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <div className="p-2 font-medium">Notificaciones</div>
              <DropdownMenuSeparator />
              <div className="p-4 text-sm">
                <div className="mb-2 rounded-md bg-blue-50 p-3 text-blue-800">
                  <p className="font-medium">Recordatorio de cita</p>
                  <p>Carlos Mendoza tiene una cita a las 15:30</p>
                </div>
                <div className="rounded-md bg-amber-50 p-3 text-amber-800">
                  <p className="font-medium">Producto con bajo stock</p>
                  <p>Gel para cabello - quedan 2 unidades</p>
                </div>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* User menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-2 rounded-full text-sm focus:outline-none">
                <Avatar>
                  <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Foto de perfil" />
                  <AvatarFallback>JD</AvatarFallback>
                </Avatar>
                <div className="hidden md:block">
                  <div className="flex items-center gap-1">
                    <div className="text-left">
                      <div className="font-medium">Juan Díaz</div>
                      <div className="text-xs text-gray-500">Administrador</div>
                    </div>
                    <ChevronDown className="h-4 w-4 text-gray-500" />
                  </div>
                </div>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                Configuración
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link href="/">
                  <LogOut className="mr-2 h-4 w-4" />
                  Cerrar sesión
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className="w-64 border-r bg-white">
          <nav className="flex flex-col p-2">
            <Link href="/dashboard" className="flex items-center gap-3 rounded-lg bg-amber-50 px-3 py-2 text-amber-700">
              <Home className="h-5 w-5" />
              <span>Inicio</span>
            </Link>
            <Link
              href="/dashboard/citas"
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-700 hover:bg-gray-100"
            >
              <Calendar className="h-5 w-5" />
              <span>Citas</span>
            </Link>
            <Link
              href="/dashboard/clientes"
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-700 hover:bg-gray-100"
            >
              <Users className="h-5 w-5" />
              <span>Clientes</span>
            </Link>
            <Link
              href="/dashboard/servicios"
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-700 hover:bg-gray-100"
            >
              <ClipboardList className="h-5 w-5" />
              <span>Servicios</span>
            </Link>
            <Link
              href="/dashboard/inventario"
              className="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-700 hover:bg-gray-100"
            >
              <Package className="h-5 w-5" />
              <span>Inventario</span>
            </Link>
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 bg-gray-50 p-6">{children}</main>
      </div>
    </div>
  )
}
